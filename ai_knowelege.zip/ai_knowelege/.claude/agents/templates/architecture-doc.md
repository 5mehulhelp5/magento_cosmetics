# {Title}

> **Date:** {YYYY-MM-DD}  
> **Module:** `{Vendor_ModuleName}` (or `N/A` if cross-cutting)  
> **Status:** Draft | Final

## Summary
{One-paragraph executive summary}

## Recommendation
{Architecture recommendation with rationale}

## Module Structure
{Directory tree and key classes/interfaces}

## Dependency Map
{Mermaid diagram or bulleted list}

## Risk Assessment
{Impact on existing environments}

## Alternative Approaches
{What was considered and why rejected}

## Implementation Plan
{Phases and tasks — omit if not applicable}
