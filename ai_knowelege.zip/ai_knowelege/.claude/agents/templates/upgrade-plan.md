# Adobe Commerce Upgrade Plan: {current-version} → {target-version}

**Prepared:** {date}
**Status:** Draft
**Source version:** {current}
**Target version:** {target}

---

## Agenda

1. [Executive Summary](#1-executive-summary)
2. [Complexity Assessment](#2-complexity-assessment)
3. [Services & Environments](#3-services--environments)
   - [3a. Adobe Commerce Cloud Config](#3a-adobe-commerce-cloud-config) *(Cloud only)*
4. [Breaking Changes & Mandatory Prerequisites](#4-breaking-changes--mandatory-prerequisites)
5. [Third-Party Dependency Audit](#5-third-party-dependency-audit)
6. [Custom Module Audit](#6-custom-module-audit)
7. [Pre-Upgrade Phase](#7-pre-upgrade-phase)
8. [Upgrade Execution](#8-upgrade-execution)
9. [Post-Upgrade Validation](#9-post-upgrade-validation)
10. [Rollback Strategy](#10-rollback-strategy)
11. [Timeline & Phased Execution](#11-timeline--phased-execution)
12. [Open Questions & Decisions Required](#12-open-questions--decisions-required)

---

### Target Stack

| Component | Current | Target | Notes |
|-----------|---------|--------|-------|
(one row per infrastructure component)

---

## 1. Executive Summary
- Why upgrade (EOL dates, security fixes, feature benefits)
- Key risks (top 3–5)
- Upgrade type: minor version / patch / security-only

## 2. Complexity Assessment
- Overall complexity rating: LOW / MEDIUM / HIGH
- Dimension table: every component that changes (PHP, DB, search, cache, queue, Composer, etc.)
- Each dimension: current → target → what action is required

## 3. Services & Environments
- Infrastructure components and their current vs. target versions
- Environment-specific configuration differences (if multi-env)
- Dev/staging/production topology

## 3a. Adobe Commerce Cloud Config *(omit section for on-premise)*
- `.magento.app.yaml` changes required: PHP version, extensions, hooks
- `.magento/services.yaml` changes required: service versions (table: service | current | target | action)
- `.magento.env.yaml` changes required: deprecated variables, search/cache/queue config updates

## 4. Breaking Changes & Mandatory Prerequisites
- One subsection per breaking change
- Each must include: impact scope, technical details, action items with checkboxes
- Cover at minimum: PHP version, DB version, search engine, message queue, Composer, deprecated APIs, security fixes requiring code changes

## 5. Third-Party Dependency Audit
- Risk matrix table: package | current version | target/required version | risk level | action
- Vendor contact status for HIGH-risk packages

## 6. Custom Module Audit
- PHP compatibility scan results summary
- REST API / webapi.xml audit
- Deprecated API usage
- Static analysis findings (PHPStan / PHPCS)

## 7. Pre-Upgrade Phase
- Audit tasks with ownership
- Code preparation tasks
- Environment preparation checklist
- Staging-first validation plan

## 8. Upgrade Execution
- Step-by-step commands for the upgrade
- Pre-upgrade (maintenance mode, backups, clear generated)
- Composer update commands
- Magento upgrade commands (setup:upgrade, di:compile, static-content:deploy, reindex)
- Environment-specific notes

## 9. Post-Upgrade Validation
- Core platform checks (logs, module status, indexer status, cron)
- Functional test matrix: area | test case | priority
- Performance baseline comparison
- Log monitoring plan (first 48 hours)

## 10. Rollback Strategy
- Rollback triggers (what conditions warrant a rollback)
- Rollback procedure (step-by-step commands)
- Rollback window

## 11. Timeline & Phased Execution
- Phase breakdown with activities, ownership, and gates
- Production deployment waves (if multi-environment)
- Regression buffer

## 12. Open Questions & Decisions Required
- Numbered table: question | owner | deadline | status
- Include any unresolved compatibility findings from Steps 3–4
