---
description: "Add Alpine.js CSP-safe script boilerplate to a Hyvä PHTML template."
---

Apply to the active `.phtml` file (skip each step if already present):

**1. `use` statement** — insert `use Hyva\Theme\ViewModel\HyvaCsp;` in alphabetical order:
`Hyva\...` < `Lippert\...` < `Magento\...` (within Hyva: `HyvaCsp` < `Media`)

**2. `@var` phpdoc** — add `/** @var HyvaCsp $hyvaCsp */` after the last `@var` line.

**3. Script block** — append at end of file. Derive function name from filename in camelCase (`cart-page.phtml` → `initCartPage`):

```php
<script>
    'use strict';

    function initAction() {
        return {
            init() {},
        }
    }

    window.addEventListener('alpine:init', () => {
        Alpine.data('initAction', initAction)
    }, { once: true })
</script>
<?php isset($hyvaCsp) && $hyvaCsp->registerInlineScript() ?>
```

Use `replace_string_in_file` — do not rewrite unchanged code. `registerInlineScript()` must be the last line.


