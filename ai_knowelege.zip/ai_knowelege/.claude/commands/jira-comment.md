---
description: "Post a comment to a Jira ticket. Usage: /jira-comment <TICKET-ID> <message or 'summary' to auto-generate from current code changes>"
---

# Jira Comment Poster

You are given a Jira ticket ID and a comment message (or the keyword `summary` to auto-generate one from current code changes). Post the comment to the ticket via the Jira REST API.

## Steps

1. **Read credentials** from the project `.env` file:

   > **IMPORTANT: Run this as its own terminal command, alone — do NOT combine it with any `curl` call below. Variable assignments are dropped when commands are chained across tool calls.**

   ```sh
   export JIRA_DC_URL=$(grep '^JIRA_DC_URL=' .env | cut -d'=' -f2- | tr -d '"' | sed 's:/*$::') && export JIRA_ACCESS_TOKEN=$(grep '^JIRA_ACCESS_TOKEN=' .env | cut -d'=' -f2- | tr -d '"') && echo "URL set: $(echo $JIRA_DC_URL | cut -c1-30)..."
   ```
   - If either is empty, ask the user to set `JIRA_DC_URL` and `JIRA_ACCESS_TOKEN` in `.env`

2. **Parse inputs** from the user's message:
   - **Ticket ID**: first token matching `[A-Z][A-Z0-9]+-\d+` (e.g. `COS-1234`)
   - **Comment body**: everything after the ticket ID; if the remaining text is `summary` or empty, proceed to step 3

3. **Auto-generate comment** (only when the message is `summary` or empty):
   - Run `git diff --name-only HEAD` to list changed files
   - Run `git diff HEAD` to get the full diff
   - Compose a concise, professional comment that describes:
     - What was changed and why (inferred from diff)
     - Key files / modules affected
     - Any notable implementation decisions
   - Use plain text (no Markdown — Jira renders its own wiki markup)

4. **Post the comment** via the Jira REST API — run this as a **separate** terminal command, after step 1 has completed:
   ```sh
   curl -s -X POST "${JIRA_DC_URL}/rest/api/2/issue/${TICKET_ID}/comment" \
     -H "Authorization: Bearer ${JIRA_ACCESS_TOKEN}" \
     -H "Content-Type: application/json" \
     -d "{\"body\": \"${COMMENT_BODY}\"}"
   ```
   - Escape any double-quotes in `COMMENT_BODY` before passing it to `curl`
   - A successful response returns HTTP 201 with the created comment JSON

5. **Confirm** the result to the user:
   - On success: display the ticket link `{JIRA_DC_URL}/browse/{TICKET_ID}` and a preview of the posted comment
   - On failure: show the HTTP status code and error message from the response body
