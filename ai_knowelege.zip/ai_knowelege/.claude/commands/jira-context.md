---
description: "Fetch Jira ticket context. Provide one or more ticket IDs (comma-separated) to retrieve summaries, descriptions, and acceptance criteria from Jira DC."
---

# Jira Ticket Context Loader

You are given one or more Jira ticket IDs. Fetch their details via the Jira REST API and summarize the context for the current task.

## Steps

1. **Read credentials** from the project `.env` file:

   > **IMPORTANT: Run this as its own terminal command, alone — do NOT combine it with the `curl` call below. Variable assignments are dropped when commands are chained across tool calls.**

   ```sh
   export JIRA_DC_URL=$(grep '^JIRA_DC_URL=' .env | cut -d'=' -f2- | tr -d '"' | sed 's:/*$::') && export JIRA_ACCESS_TOKEN=$(grep '^JIRA_ACCESS_TOKEN=' .env | cut -d'=' -f2- | tr -d '"') && echo "URL set: $(echo $JIRA_DC_URL | cut -c1-30)..."
   ```
   - If either is empty, ask the user to set `JIRA_DC_URL` and `JIRA_ACCESS_TOKEN` in `.env`

2. **Parse ticket IDs** from the user's message:
   - Accept comma-separated IDs (e.g., `COS-1234, COS-1235`)
   - Accept space-separated or inline mentions
   - Pattern: any string matching `[A-Z][A-Z0-9]+-\d+`

3. **Fetch tickets via Jira REST API** — run this `curl` as a **separate** terminal command, after step 1 has completed:
   ```sh
   curl -s -X POST "${JIRA_DC_URL}/rest/api/2/search" \
     -H "Authorization: Bearer ${JIRA_ACCESS_TOKEN}" \
     -H "Content-Type: application/json" \
     -d '{
       "jql": "key IN (COS-1234, COS-1235)",
       "fields": ["key", "summary", "status", "priority", "description", "issuelinks", "components", "labels", "assignee"]
     }'
   ```
   - Replace the `key IN (...)` list with the actual detected ticket IDs
   - This returns JSON with all ticket data in one request

4. **Parse the JSON response** and summarize each ticket:
   - **Ticket ID** (`key`) and link: `{JIRA_DC_URL}/browse/{key}`
   - **Summary** (`fields.summary`)
   - **Status** (`fields.status.name`) and **Priority** (`fields.priority.name`)
   - **Description** (`fields.description`) — condensed to key requirements
   - **Acceptance Criteria** — extract from description if present (look for "Acceptance Criteria" heading)
   - **Linked issues** (`fields.issuelinks`) — if any
   - **Affected modules** — from components, labels, or description mentions of WEG modules/environments

5. **Return** a structured summary that can be used as context for subsequent coding tasks.

## Output Format

For each ticket:

```
### {TICKET_ID}: {Summary}
- **Status**: {status} | **Priority**: {priority}
- **Description**: {condensed description}
- **Acceptance Criteria**: {list}
- **Affected areas**: {modules, environments, or components mentioned}
```

If the API returns an error (401, 403, network failure), report the HTTP status and suggest the user verify `JIRA_ACCESS_TOKEN` in `.env`.
