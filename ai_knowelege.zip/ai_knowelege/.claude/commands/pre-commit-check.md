---
description: "Run pre-commit quality checks on staged or changed files. Validates PHP syntax, coding standards, security patterns, and common Magento 2 anti-patterns."
---

Run a pre-commit quality check on the currently changed files. Use `git diff --name-only HEAD` to identify them.

For each changed PHP file:
1. **Syntax**: Verify valid PHP (`php -l`)
2. **Strict types**: Confirm `declare(strict_types=1)` is present
3. **Security scan**: Check for forbidden patterns:
   - `ObjectManager::getInstance()`
   - Direct superglobal access (`$_GET`, `$_POST`, `$_REQUEST`)
   - `eval()`, `unserialize()`, `shell_exec()` with variables
4. **Debug code**: No `var_dump()`, `print_r()`, `debug_backtrace()`, commented-out code
5. **Standards**: PSR-12 compliance, return types, typed properties
6. **Magento patterns**: No class rewrites when plugins suffice, proper DI, avoid `around` plugins when `before`/`after` suffice
7. **Privacy**: Customer data not leaking between loop iterations

For each changed PHTML file:
1. All output escaped: `$escaper->escapeHtml()`, `escapeUrl()`, `escapeHtmlAttr()` — raw `echo $` is an XSS vulnerability
2. No business logic — use ViewModels for data preparation, keep templates display-only
3. No direct `$_GET`/`$_POST`/`$_REQUEST` access

For each changed XML file:
1. Schema URN references present
2. Valid XML structure
3. `cacheable="false"` NOT on catalog, product, or CMS page blocks (disables FPC for entire page)

For each changed JS file:
1. `'use strict'` present
2. No `innerHTML` or `.html()` with variables
3. RequireJS `define()` pattern used

If `vendor/bin/phpcs` is available, run it against changed PHP/PHTML files: `vendor/bin/phpcs {file} --standard=Magento2`
If `vendor/bin/phpstan` is available, run it against changed PHP files: `vendor/bin/phpstan analyse {file}`

Report a clear PASS/FAIL with any issues found.
