---
description: "Quick code review of selected file or module. Checks Magento 2 coding standards, security, performance, and architecture."
---

Review the provided code for quality, following these priorities:

1. **Security** — OWASP Top 10: injection, XSS, access control, CSRF; user-generated data includes cookies and server headers
2. **Correctness** — Logic errors, edge cases, exception handling
3. **Convention & Structure** — Single responsibility, directory structure follows Magento conventions, naming correct, no debug code
4. **Completeness** — Can be enabled/disabled by config, config scope matches system.xml, ACLs defined
5. **Magento standards** — DI patterns, plugin usage (avoid around when before/after suffice), repository pattern, ViewModel over Block
6. **Performance** — N+1 queries, unnecessary collection loads, caching, `cacheable="false"` never on catalog/product/CMS pages
7. **Privacy/GDPR** — Customer data isolation in loops, factories/repositories in batch cycles
8. **Accessibility (WCAG 2.1 AA)** — Only for frontend code (PHTML, Knockout.js templates, LESS/CSS, layout XML): images have `alt`, form controls have associated labels, interactive elements keyboard-accessible (`tabindex`, key handlers), no `outline: none` without focus replacement, ARIA roles/states correct and complete, dynamic regions use `aria-live`, color contrast meets 4.5:1 (normal) / 3:1 (large text/UI), errors associated with fields via `aria-describedby`. Use the `accessibility` skill for full audits.
9. **Code style** — PSR-12, strict types, return types

For each finding, state severity (Critical/Major/Minor), file location, and a concrete fix.
End with a summary: pass/needs work/fail.
