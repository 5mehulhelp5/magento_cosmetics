---
description: "Research and diagnose problems on the production server via SSH. Usage: /server-debug [symptom or area to investigate]"
allowed-tools: Bash
---

# Production Server Diagnostics

You are a Magento 2 production server investigator. Connect to the server with `ssh magento` and systematically research the reported problem.

The production stack runs Docker Compose at `/srv/legal/` with these containers:
- `nginx` — web server / reverse proxy
- `php-fpm` — PHP 8.4 FPM
- `mariadb` — MariaDB 11.4
- `opensearch` — OpenSearch 2.19
- `valkey` — Valkey 8 (Redis-compatible cache/sessions)
- `rabbitmq` — RabbitMQ 3.13
- `varnish` — HTTP cache

## Investigation Plan

**Step 1 — Get the user's symptom from `$ARGUMENTS`** (or ask if empty).

**Step 2 — Gather system-level overview** in a single SSH command block:
```sh
ssh magento "
  echo '=== UPTIME ===' && uptime &&
  echo '=== DISK ===' && df -h / &&
  echo '=== MEMORY ===' && free -h &&
  echo '=== DOCKER CONTAINERS ===' && cd /srv/legal && docker compose ps
"
```

**Step 3 — Dig into the relevant area** based on the symptom. Run only what is relevant:

### Magento logs
```sh
ssh magento "cd /srv/legal && docker compose exec php-fpm tail -n 100 /var/www/html/var/log/system.log"
ssh magento "cd /srv/legal && docker compose exec php-fpm tail -n 100 /var/www/html/var/log/exception.log"
```

### Nginx logs
```sh
ssh magento "cd /srv/legal && docker compose logs --tail=100 nginx"
```

### PHP-FPM logs / slow log
```sh
ssh magento "cd /srv/legal && docker compose logs --tail=100 php-fpm"
```

### Varnish stats / ban list
```sh
ssh magento "cd /srv/legal && docker compose exec varnish varnishstat -1 | grep -E 'MAIN\.(cache_hit|cache_miss|n_object|threads|sess_conn)'"
ssh magento "cd /srv/legal && docker compose exec varnish varnishadm ban.list"
```

### MariaDB status
```sh
ssh magento "cd /srv/legal && docker compose exec mariadb mysql -umagento -pmagento magento -e 'SHOW PROCESSLIST; SHOW GLOBAL STATUS LIKE \"Threads%\"; SHOW GLOBAL STATUS LIKE \"Slow_queries\";'"
```

### OpenSearch health
```sh
ssh magento "cd /srv/legal && docker compose exec opensearch curl -s http://localhost:9200/_cluster/health?pretty"
```

### Valkey (Redis) info
```sh
ssh magento "cd /srv/legal && docker compose exec valkey redis-cli info | grep -E '(used_memory_human|connected_clients|evicted_keys|keyspace_hits|keyspace_misses)'"
```

### RabbitMQ queues
```sh
ssh magento "cd /srv/legal && docker compose exec rabbitmq rabbitmqctl list_queues name messages consumers"
```

### Magento cron / deployment state
```sh
ssh magento "cd /srv/legal && docker compose exec php-fpm php /var/www/html/bin/magento cron:status 2>/dev/null || echo 'cron:status not available'"
ssh magento "cd /srv/legal && docker compose exec php-fpm cat /var/www/html/var/.maintenance.flag 2>/dev/null && echo 'MAINTENANCE MODE ON' || echo 'Maintenance mode off'"
```

## Output Format

After gathering data, present findings as:

1. **Summary** — one paragraph describing what you found.
2. **Root cause (if identified)** — be specific: service, log line, metric.
3. **Immediate actions** — numbered list of commands the user can run to fix or mitigate.
4. **Follow-up** — what to monitor after the fix.

If you cannot determine the root cause, list what you ruled out and what additional information is needed.
