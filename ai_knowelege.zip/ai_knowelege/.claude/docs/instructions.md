# Instructions Reference

> Rules that fire automatically when editing matching files. Most are always-on; `jira-context` is referenced explicitly by agents.

[← Back to overview](../README.md)

## How Instructions Work

Instructions are `.instructions.md` files in `.claude/instructions/`. Each has an `applyTo` glob pattern — when you open or edit a file matching that pattern, the instruction is loaded into the AI context automatically.

This means: **you never invoke these manually**. Edit a `.php` file and both PHP standards and security rules are active.

## Instruction Files

### magento-php.instructions.md

| | |
|---|---|
| **Applies to** | `app/**/*.php` or `modules/**/*.php` (depending on convention) |
| **Purpose** | PHP coding standards, DI, plugins, repositories, error handling |

**Key rules:**
- Constructor injection only — no `ObjectManager`
- Type-hint interfaces, not concrete classes
- Plugins over rewrites; `before`/`after` over `around`
- `declare(strict_types=1)` on all files
- Return type declarations, typed properties
- Specific exception types, never silent catch
- Repository pattern with SearchCriteria
- No full collection loads — always filter + paginate

### security-php.instructions.md

| | |
|---|---|
| **Applies to** | `app/**/*.php` or `modules/**/*.php` (depending on convention) |
| **Purpose** | OWASP Top 10 security enforcement |

**OWASP coverage:**

| Category | Key Rules |
|----------|-----------|
| A01 Broken Access Control | ACL in admin controllers, session validation, CSRF form keys |
| A02 Cryptographic Failures | Use `EncryptorInterface`, no hardcoded credentials, no `md5()`/`sha1()` |
| A03 Injection | Parameter binding for SQL, no `shell_exec()` with user input, no `eval()` |
| A05 Security Misconfiguration | No stack traces to users, no sensitive data in logs |
| A07 XSS | `$escaper->escapeHtml()` for all output contexts |
| A08 Insecure Deserialization | No `unserialize()` — use JSON serializer |
| A10 SSRF | Validate/whitelist URLs before HTTP requests |

**Forbidden patterns** (the AI will never generate these):
- `ObjectManager::getInstance()`
- `$_GET`, `$_POST`, `$_REQUEST`, `$_SERVER`
- `echo`, `print` outside templates
- `file_get_contents()` with remote URLs
- `md5()`, `sha1()` for security

### phtml-templates.instructions.md

| | |
|---|---|
| **Applies to** | `app/**/*.phtml` or `modules/**/*.phtml` (depending on convention) |
| **Purpose** | XSS prevention via mandatory output escaping |

**Escaping rules:**
- HTML body: `$escaper->escapeHtml($value)`
- HTML attributes: `$escaper->escapeHtmlAttr($value)`
- URLs: `$escaper->escapeUrl($value)`
- JavaScript: `$escaper->escapeJs($value)`
- CSS: `$escaper->escapeCss($value)`
- `__()` does NOT escape — always wrap in `$escaper`

### javascript-frontend.instructions.md

| | |
|---|---|
| **Applies to** | `app/**/*.js` or `modules/**/*.js` (depending on convention) |
| **Purpose** | RequireJS, Knockout.js, jQuery conventions, XSS prevention |

**Key rules:**
- RequireJS `define()` pattern for all modules
- Mixins over full file overrides
- Never `innerHTML` or `.html()` with user input
- `'use strict'` in all modules
- `domReady!` instead of `$(document).ready()`
- Lazy-load JS, no synchronous AJAX

### magento-xml.instructions.md

| | |
|---|---|
| **Applies to** | `app/**/*.xml` or `modules/**/*.xml` (depending on convention) |
| **Purpose** | XML config conventions — di.xml, system.xml, module.xml, layout XML, events, crontab |

**Key rules:**
- Always include `xsi:noNamespaceSchemaLocation` URN references
- Use `sequence` in `module.xml` to declare module load order
- Prefer layout XML changes over PHTML overrides
- `cacheable="false"` on any block disables FPC for the entire page — never on content pages
- Configuration scope in `system.xml` must match how the value is retrieved in code
- Sensitive config fields must use `Encrypted` backend model

### theme-development.instructions.md

| | |
|---|---|
| **Applies to** | `app/design/**` and `app/theme-*/**` |
| **Purpose** | Theme file structure, LESS/CSS conventions, layout vs template decisions, caching rules |

**Key rules:**
- Base themes extend Magento Blank or Luma — child themes inherit everything from parent
- Extend default styles via `_extend.less` — don't override parent LESS files
- Style custom modules inside the module (`view/frontend/web/css/source/`), not in the theme
- Prefer layout XML changes over PHTML overrides
- Change wording via CSV translation dictionaries, not by overriding templates
- `cacheable="false"` on any block disables FPC for the entire page — never on content pages

---

### jira-context.instructions.md

| | |
|---|---|
| **Applies to** | Referenced explicitly by agents when a Jira ticket ID is detected |
| **Purpose** | Fetch Jira ticket context from Jira DC REST API |

**Key behaviour:**
- Triggered by agents (e.g. `@magento-architect`, `@magento-module-builder`) when a Jira ticket ID pattern (`PROJ-1234`) is detected in the conversation
- Reads `JIRA_DC_URL` and `JIRA_ACCESS_TOKEN` from the project `.env` file
- Fetches summary, description, acceptance criteria, status, priority, linked issues, and affected modules via a single `POST /rest/api/2/search` call
- Does not block work if the API call fails — notes the error and continues
- Use `/jira-context TICKET-123` to fetch context explicitly at any time

**Setup:** Add to `.env` in the project root:
```sh
JIRA_DC_URL=https://jira.mage.com
JIRA_ACCESS_TOKEN=your-personal-access-token
```

## Adding a New Instruction

1. Create `.claude/instructions/{name}.instructions.md`
2. Add frontmatter with `description` and `applyTo`:
   ```yaml
   ---
   description: "Use when editing {type} files. Covers {topic}."
   applyTo: "modules/**/*.{ext}"
   ---
   ```
3. Write concise, actionable rules (the AI reads this every time it edits a matching file)
4. Update this doc

**Tip**: Keep instructions focused — one concern per file. Don't mix security rules with style rules.
