# Skills Reference

> On-demand workflows triggered via `/` commands in chat or auto-detected by the AI when relevant.

[← Back to overview](../README.md)

## How Skills Work

Skills are `SKILL.md` files in `.claude/skills/{name}/`. They appear as slash commands (type `/` in chat) and contain step-by-step procedures with checklists, templates, and structured output formats.

Unlike instructions (always-on), skills are loaded **only when invoked** — they're ideal for heavyweight workflows like code reviews or audits.

## Available Skills

### `/code-review`

| | |
|---|---|
| **Location** | `.claude/skills/code-review/SKILL.md` |
| **Purpose** | Comprehensive PHP code review for Magento 2 modules |
| **Invocation** | `/code-review modules/module-mage-checkout/` |

**Review checklist (11 categories):**

1. **Coding Standards** — strict types, return types, typed properties, PSR-12
2. **Convention & Structure** — single responsibility, Magento directory layout, naming, no debug code
3. **Dependency Injection** — constructor injection, interface type-hints, no ObjectManager
4. **Plugin Quality** — before/after over around, no construct plugins, sortOrder, correct return types
5. **Completeness** — config flags, ACL definitions, config scope matches `system.xml`, PhpDocs
6. **Security & Privacy/GDPR** — OWASP Top 10 applied to Magento (injection, XSS, ACL, CSRF), customer data isolation
7. **Performance** — collection loading, N+1 queries, caching, `cacheable="false"` misuse
8. **Architecture** — repository pattern, service contracts, ViewModels, module dependencies
9. **Error Handling** — specific exceptions, logging, no silent catches
10. **Configuration** — di.xml schema, system.xml validation, encrypted backend model
11. **Accessibility (WCAG 2.1 AA)** — frontend code: alt text, labels, keyboard access, ARIA, contrast

**Output**: Structured report with severity (Critical/Major/Minor/Suggestion), location, issue, fix.

---

### `/security-audit`

| | |
|---|---|
| **Location** | `.claude/skills/security-audit/SKILL.md` |
| **Purpose** | OWASP-focused deep security audit |
| **Invocation** | `/security-audit modules/module-mage-api/` |

**3-phase audit:**

1. **Automated Pattern Scan** — searches for dangerous patterns across 7 OWASP categories
2. **Access Control Review** — verifies ACL on all controllers and API endpoints
3. **Data Flow Analysis** — traces user input from entry point to persistence/output

**Scan categories**: Injection (A03), XSS (A07), Broken Access Control (A01), Cryptographic Failures (A02), Insecure Deserialization (A08), SSRF (A10), Security Misconfiguration (A05)

---

### `/performance-review`

| | |
|---|---|
| **Location** | `.claude/skills/performance-review/SKILL.md` |
| **Purpose** | Performance anti-pattern detection and optimization |
| **Invocation** | `/performance-review modules/module-mage-catalog/` |

**Review areas:**

| Area | What it checks |
|------|---------------|
| Collections & Queries | Full collection loads, missing filters, missing pagination |
| N+1 Detection | Models loaded inside loops, batch loading opportunities |
| Caching | Missing cache, wrong cache tags, FPC compatibility |
| Indexers | Mview usage, batch processing, reindex triggers |
| Frontend JS | Lazy loading, sync AJAX, domReady usage |
| Frontend CSS | Import bloat, critical CSS, LESS compilation |
| Layout XML | Unnecessary blocks, `cacheable="false"` misuse |
| Elasticsearch | Wildcard queries, aggregation limits, field types |

---

### `/elasticsearch`

| | |
|---|---|
| **Location** | `.claude/skills/elasticsearch/SKILL.md` |
| **Purpose** | Elasticsearch expertise for Magento 2 |
| **Invocation** | `/elasticsearch Why are products missing from search on CZ?` |

**Capabilities:**
- Debug search/filter issues (missing results, wrong relevance)
- Add custom searchable/filterable attributes
- Optimize query performance
- Tune relevance with field boosting and function_score
- Troubleshoot reindex failures
- Environment-specific: per-environment index, multi-language analyzers

---

### `/module-documentation`

| | |
|---|---|
| **Location** | `.claude/skills/module-documentation/SKILL.md` |
| **Purpose** | Generate module README.md and update central registry |
| **Invocation** | `/module-documentation modules/module-mage-checkout` |

**Procedure:**

1. Reads `composer.json`, `module.xml`, `di.xml`, `webapi.xml`, `db_schema.xml`, `system.xml`, `events.xml`, `crontab.xml`
2. Generates `README.md` with: overview, features, architecture, dependencies, mermaid diagrams, configuration table, API endpoints, database schema, events, cron jobs
3. Updates the central registry at `docs/modules/README.md`
4. Creates an ADR if the module introduces a significant architecture decision

**Templates included**: Module README, central registry table, ADR format.

---

### `/phpunit`

| | |
|---|---|
| **Location** | `.claude/skills/phpunit/SKILL.md` |
| **Purpose** | Generate PHPUnit tests for Magento 2 classes |
| **Invocation** | `/phpunit modules/module-mage-checkout/src/Model/Payment.php` |

**Procedure:**

1. Analyzes the target class — public methods, constructor dependencies, return types
2. Creates test class mirroring the source namespace under `Test/Unit/`
3. Generates mocks for all Magento dependencies (repositories, collections, requests)
4. Writes tests following Arrange-Act-Assert pattern with descriptive names

**Key features:**
- Uses PHPUnit base class and optional testing tools helpers (`real()`, `mock()`, `get()`, `deep()`)
- Matches existing test directory pattern in the module (`src/Test/Unit/` or `test/Unit/`)
- Built-in mock recipes for common Magento types (Repository, SearchCriteria, Request, Collection)
- Quality checklist: one assertion per test, no logic in tests, edge cases, fast execution

**Output**: Complete test class file + `AbstractTestCase` if missing + suggested additional test cases.

### `/accessibility`

| | |
|---|---|
| **Location** | `.claude/skills/accessibility/SKILL.md` |
| **Purpose** | WCAG 2.1 AA accessibility audit and remediation for Magento 2 frontend code |
| **Invocation** | `/accessibility modules/module-mage-checkout/` |

**4-phase audit:**

1. **Automated Pattern Scan** — searches PHTML, Knockout, LESS, and XML for 12 categories of accessibility anti-patterns
2. **Component-Specific Checks** — targeted checklists for modals, menus, tabs, accordions, tables, AJAX notifications, and carousels
3. **Knockout.js Template Checks** — Magento 2-specific `data-bind` accessibility patterns
4. **LESS/CSS Accessibility Checks** — focus indicators, reduced-motion, high-contrast, and `.sr-only` patterns

**Scan categories (WCAG 2.1 AA):**

| Category | WCAG SC |
|----------|---------|
| Images & Non-Text Content | 1.1.1 |
| Form Controls & Labels | 1.3.1, 4.1.2 |
| Semantic Structure | 1.3.1, 1.3.2 |
| ARIA Usage | 4.1.2 |
| Keyboard Accessibility | 2.1.1, 2.1.2 |
| Focus Management | 2.4.3, 2.4.7, 3.2.1 |
| Color & Contrast | 1.4.1, 1.4.3, 1.4.11 |
| Text Resize & Reflow | 1.4.4, 1.4.10 |
| Link & Button Purpose | 2.4.4, 2.4.9 |
| Language | 3.1.1, 3.1.2 |
| Error Identification | 3.3.1, 3.3.2, 3.3.3 |
| Page Titles & Landmarks | 2.4.1, 2.4.2 |

**Output**: Findings grouped by WCAG principle with severity, location, rule violation, and ready-to-use remediation code snippets (PHTML, Knockout, LESS).

---

### `/hyva-csp`

| | |
|---|---|
| **Location** | `.claude/skills/hyva-csp/SKILL.md` |
| **Purpose** | CSP compliance check and auto-fix for Hyvä PHTML templates |
| **Invocation** | `/hyva-csp path/to/template.phtml` |

**5-step process:**

1. **Read the file** — reads the target `.phtml`
2. **Check boilerplate** — verifies and adds `use Hyva\Theme\ViewModel\HyvaCsp;`, `@var HyvaCsp $hyvaCsp` phpdoc, and `registerInlineScript()` as the last line
3. **Fix Alpine anti-patterns** — extracts inline arguments from Alpine directives, dot-access expressions to named `get`-prefixed methods, removes inline `onclick`/`onchange` attributes
4. **Apply fixes** — targeted string replacements; does not rewrite unchanged code
5. **Report** — lists every change applied (`🔧 FIXED`) and anything requiring manual intervention (`⚠️ MANUAL`)

**Auto-fix categories:**

| Category | What it fixes |
|---|---|
| HyvaCsp boilerplate | Missing `use`, `@var`, `registerInlineScript()` |
| Inline Alpine arguments | `@click="fn($event)"` → `@click="fn"` + method update |
| Dot-access expressions | `x-text="item.name"` → `x-text="getItemName"` + getter method |
| Inline event attributes | `onclick="..."` → Alpine `@click` + named method |
| Escaping violations | Flags `<?= $var ?>` without `$escaper->*` or `/* @noEscape */` |

---

## Creating a New Skill

1. Create `.claude/skills/{name}/SKILL.md`
2. Add frontmatter:
   ```yaml
   ---
   name: skill-name
   description: "Keyword-rich description. Use when {triggers}."
   argument-hint: "What to pass as input"
   ---
   ```
3. Write: When to Use → Procedure (numbered steps) → Output Format
4. Keep SKILL.md under 500 lines; use `./references/` for supplementary docs
5. Update this doc
