# AI-Engineering Workflow

> How the AI customization layers work together in day-to-day development.

[← Back to overview](../README.md)

## The Full Picture

Seven agents, seven skills, seven instruction sets, and one security hook — working together across three phases with human approval checkpoints.

```mermaid
flowchart LR
    A["① Solution & Plan\n@magento-architect"]
    H["② Human Review\n& Approval"]
    D["③ Develop\n@magento-module-builder\n@magento-implementation\nInstructions + Hook"]
    R["④ Review\n@magento-quality"]

    A --> H --> D --> R
```

The sequence below shows how the layers interact during a typical plan → implement pipeline:

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant Arch as @magento-architect
    participant Impl as @magento-implementation
    participant Hook as Security Hook
    participant QA as @magento-quality
    participant Skill as Skill

    Note over Dev,Skill: ① Solution & Plan
    Dev->>Arch: Describe the feature or change
    Arch-->>Dev: Architecture plan (structure, interfaces, deps)

    Note over Dev,Skill: ② Human Review
    Dev->>Dev: Review & approve architecture plan

    Note over Dev,Skill: ③ Implement
    Dev->>Impl: "Implement the plan"
    Impl->>Impl: Validate plan & create task list
    Note right of Impl: magento-php + security-php<br/>instructions auto-load
    Impl->>Hook: Write / modify files
    Hook-->>Impl: ✅ Clean

    Note over Dev,Skill: ④ Quality Gates
    Impl->>QA: Delegate quality gates
    QA->>Skill: code-review
    Skill-->>QA: 1 Minor — auto-fixed
    QA->>Skill: performance-review
    Skill-->>QA: ✅ PASS
    QA->>Skill: accessibility
    Skill-->>QA: ✅ PASS
    QA->>Skill: phpunit
    Skill-->>QA: ✅ PASS
    QA->>Skill: security-audit
    Skill-->>QA: ✅ PASS
    QA->>Skill: module-documentation
    Skill-->>QA: ✅ PASS
    QA-->>Impl: All gates passed ✅

    Note over Dev,Skill: ⑤ Delivery
    Impl-->>Dev: Delivery checklist — all gates passed
```

## Workflow by Scenario

### Scenario A: New Feature

```mermaid
flowchart LR
    J["/jira-context\n(optional)"]
    A["① Solution & Plan\n@magento-architect"]
    H["② Review\nHuman approval"]
    D["③ Implement\n@magento-implementation"]
    R["④ Quality\n@magento-quality · @security-reviewer\n(all 6 gates · deep OWASP)"]

    J --> A --> H --> D --> R
```

Full pipeline: Jira context → architect designs solution → human approves architecture → implementation builds it → quality runs all six gates plus a security deep-dive.

0. **Jira context** *(optional)* — Mention `PROJ-123` or run `/jira-context` to load requirements and AC
1. **Solution & Plan** — `@magento-architect "PROJ-123: Design the order export API"` — outputs module structure, service contracts, REST/GraphQL API, ACL, risk assessment
2. **Review & approve** — architect outputs target module(s), affected files, service contracts, risk assessment; refine if needed
3. **Implement** — `@magento-implementation "Implement the plan from @magento-architect for PROJ-123"` — agent validates plan, creates task list, builds code, delegates to `@magento-quality` for all six gates with auto-fix; quality triggers `@security-reviewer` for OWASP deep-dive
4. **Delivery** — agent presents pass/fail checklist; only delivers when all gates pass
5. **Comment** *(optional)* — `/jira-comment PROJ-123 summary`
6. **Commit** — `git commit -m "feat(catalog): order export API [PROJ-123]"`

---

### Scenario B: Bug Fix

```mermaid
flowchart LR
    A["① Diagnose\n@magento-architect"]
    H["② Review\nHuman approval"]
    D["③ Fix\n@magento-implementation"]
    R["④ Validate\n@magento-quality\ncode-review · security-audit"]

    A --> H --> D --> R
```

`@magento-architect` diagnoses the root cause and writes a structured fix plan. Human reviews and approves before `@magento-implementation` executes. `@magento-quality` validates with targeted code review and security audit gates.

0. **Jira context** *(optional)* — Mention `PROJ-456` or run `/jira-context` to load reproduction steps
1. **Diagnose** — `@magento-architect "PROJ-456: Diagnose null pointer in CustomerRepository::getById()"` — agent identifies root cause, affected files, and writes a fix plan; for trivial fixes, skip to step 3 and use Agent mode directly
2. **Review & approve** — architect outputs root cause analysis and structured fix plan; refine if needed
3. **Fix** — `@magento-implementation "Implement the fix from @magento-architect for PROJ-456"` — agent reads existing code, applies surgical fix, delegates to `@magento-quality`
4. **Validate** — quality agent runs code review + security audit gates with auto-fix loop
5. **Delivery** — pass/fail checklist; only delivers when all gates pass
6. **Comment** *(optional)* — `/jira-comment PROJ-456 summary`
7. **Commit** — `git commit -m "fix(customer): null pointer in getById [PROJ-456]"`

---

### Scenario C: Performance Investigation

```mermaid
flowchart LR
    S["/performance-review\nskill"]
    A["② Plan\n@magento-architect"]
    H["③ Review\nHuman approval"]
    D["④ Optimize\n@magento-implementation"]
    R["⑤ Verify\n@magento-quality"]

    S --> A --> H --> D --> R
```

`/performance-review` audits N+1 queries, FPC violations, and Elasticsearch misuse. Findings are escalated to `@magento-architect` who designs optimizations. Human approves plan before implementor applies changes. `@magento-quality` re-verifies gains after implementation.

0. **Jira context** *(optional)* — Mention `PROJ-789` to load performance acceptance criteria
1. **Audit** — `/performance-review` on the target module — scans for N+1 queries, missing FPC cache tags, collection inefficiencies, Elasticsearch misuse
2. **Plan** — `@magento-architect "PROJ-789: Design optimizations based on performance findings"` — architect reviews findings and designs targeted fixes (e.g. replace loops with JOINs, add cache identity tags)
3. **Review & approve** — review optimization plan; refine if needed
4. **Optimize** — `@magento-implementation "Implement the optimization plan from @magento-architect for PROJ-789"` — applies changes surgically
5. **Verify** — `@magento-quality` re-runs the performance gate to confirm measurable gains and no regressions
6. **Commit** — `git commit -m "perf(catalog): replace N+1 loop with join [PROJ-789]"`

---

### Scenario D: Search / Filter Bug

```mermaid
flowchart LR
    S["① Diagnose\n/elasticsearch"]
    D["② Fix\nAgent mode"]
    R["③ Verify\n@magento-quality"]

    S --> D --> R
```

0. **Jira context** *(optional)* — Mention `PROJ-321` to load search-related AC and affected locales
1. **Diagnose** — `/elasticsearch "PROJ-321: Products missing from search on CZ"` — skill guides through index, mapping, analyser, attribute config
2. **Fix** — describe the fix in Agent mode; Hook validates
3. **Verify** — `@magento-quality` on changed files
4. **Commit** — `git commit -m "fix(search): cs_CZ analyzer for color attribute [PROJ-321]"`

---

### Scenario E: Architecture Decision

```mermaid
flowchart LR
    A["① Solution & Plan\n@magento-architect"]
    D["② Implement\n@magento-implementation"]
    R["③ Review\n@magento-quality"]

    A --> D --> R
```

0. **Jira context** *(optional)* — Mention `PROJ-100` to share business constraints with the agent
1. **Ask architect** — `@magento-architect "PROJ-100: How to structure new ERP integration?"` — outputs module structure, dependency map, risk assessment, ADR
2. **Review & approve** — refine with follow-up questions if needed
3. **Implement** — `@magento-implementation "Implement the plan from @magento-architect for PROJ-100"` — handles code, quality gates, and documentation

---

### Scenario F: Accessibility Audit & Remediation

```mermaid
flowchart LR
    S["/accessibility\nskill"]
    A["② Plan\n@magento-architect"]
    H["③ Review\nHuman approval"]
    D["④ Remediate\n@magento-implementation"]
    R["⑤ Verify\n@magento-quality"]

    S --> A --> H --> D --> R
```

`/accessibility` runs a 4-phase WCAG 2.1 AA audit (pattern scan → component checks → Knockout.js checks → CSS contrast). Findings go to `@magento-architect` for structural remediation design. Human approves plan, implementor applies changes, `@magento-quality` re-verifies compliance.

0. **Jira context** *(optional)* — Mention `PROJ-654` to load scope and target WCAG level
1. **Audit** — `/accessibility modules/module-mage-checkout/` — 4-phase WCAG 2.1 AA scan: missing ARIA labels, contrast failures, keyboard navigation gaps, Knockout.js component issues
2. **Plan** — `@magento-architect "PROJ-654: Design accessible component architecture based on a11y findings"` — architect designs ARIA roles, keyboard nav, focus management strategy
3. **Review & approve** — review remediation plan; refine if needed
4. **Remediate** — `@magento-implementation "Implement the remediation plan from @magento-architect for PROJ-654"` — applies structural and pattern fixes
5. **Verify** — `@magento-quality` re-runs WCAG 2.1 AA audit to confirm all checks pass
6. **Commit** — `git commit -m "a11y(checkout): WCAG 2.1 AA fixes [PROJ-654]"`

---

### Scenario G: Adobe Commerce Version Upgrade

```mermaid
flowchart LR
    U["① Analyze\n@magento-upgrade"]
    A["② Plan\n@magento-architect\n(breaking changes)"]
    S["② Scan\n@security-reviewer\n(custom module CVEs)"]
    H["③ Review\nHuman approval"]
    D["④ Execute\n@magento-implementation"]

    U --> A & S --> H --> D
```

`@magento-upgrade` discovers the full stack, audits third-party dependencies by risk (HIGH/MEDIUM/LOW), and delegates architectural decisions to `@magento-architect` and security review to `@security-reviewer`. Human approves the full upgrade plan before `@magento-implementation` executes pre-upgrade tasks.

0. **Jira context** *(optional)* — Mention the upgrade epic ticket to share timeline and business constraints
1. **Analyze** — `@magento-upgrade Plan the upgrade from 2.4.6 to 2.4.8` — agent discovers current stack (PHP, services, Cloud config), audits all third-party dependencies, scans custom modules for PHP compat and breaking changes
2. **Plan** — upgrade agent delegates to `@magento-architect` for breaking change review and to `@security-reviewer` for CVE scanning of custom modules; generates `docs/upgrade/upgrade-plan-2.4.8.md` with risk matrix, execution steps, and rollback strategy
3. **Review & approve** — review the full upgrade plan and security findings; refine if needed
4. **Execute pre-upgrade tasks** — `@magento-implementation` for each code-change task referenced in the plan (one at a time)

---

### Scenario H: Build a New Module

```mermaid
flowchart LR
    B["① Plan\n@magento-module-builder\n(scope clarification)"]
    A["② Architecture\n@magento-architect\n(plan + file list)"]
    H["③ Review\nHuman approval"]
    D["④ Build\n@magento-module-builder\n(implements files)"]
    R["⑤ Quality Gates\n@magento-quality\n(all 6 gates · auto-fix)"]

    B --> A --> H --> D --> R
```

`@magento-module-builder` gathers and confirms scope, then delegates to `@magento-architect` for architectural review and an implementation plan. Human approves the plan before any code is written, then the builder implements all module files. `@magento-quality` runs all six gates with auto-fix.

1. **Invoke** — `@magento-module-builder "Build a module that adds a delivery date field to the order checkout and stores it on the order"`
2. **Clarify scope** — agent asks targeted questions: admin/frontend scope, DB table needed, multi-store, REST/GraphQL, ACL, cron, CLI, admin UI
3. **Delegate to architect** — once requirements are confirmed, builder delegates to `@magento-architect` who analyses dependencies, caching impact, and service contracts; outputs full plan (file list, DB schema, DI config, service contracts)
4. **Review & approve** — architect presents the architectural plan; refine if needed, then approve to proceed
5. **Build** — builder implements all module files one by one following the approved plan
6. **Quality gates** — builder delegates to `@magento-quality` for all six gates (code review, performance, accessibility, PHPUnit, security audit, documentation) with auto-fix loop
7. **Delivery** — pass/fail checklist; only delivers when all gates pass
8. **Commit** — `git commit -m "feat(checkout): delivery date field module"`

> **From a Jira ticket:** `@magento-module-builder PROJ-1234` — agent fetches ticket context, follows the same flow, and optionally posts a summary back via `/jira-comment`.

---

### Scenario I: Solution & Plan → Implement Pipeline

```mermaid
flowchart LR
    A["① Solution & Plan\n@magento-architect"]
    H["② Review\nHuman approval"]
    D["③ Implement\n@magento-implementation"]
    R["④ Review\n@magento-quality"]

    A --> H --> D --> R
```

Use `@magento-architect` to design the solution, then hand the plan to `@magento-implementation` for execution. Recommended for changes in existing modules where architecture should be reviewed first.

0. **Jira context** *(optional)* — Mention `PROJ-200` or run `/jira-context` to load requirements
1. **Solution & Plan** — `@magento-architect "PROJ-200: Design order sync improvements in the existing OMS module"`
2. **Review & approve** — architect outputs target module(s), affected files, service contracts, dependency changes, risk assessment; refine if needed
3. **Implement** — `@magento-implementation "Implement the plan for PROJ-200"` — agent validates plan, reads existing code, creates task list, implements, delegates to `@magento-quality` for all six gates
4. **Delivery** — pass/fail checklist for quality gates + plan adherence; only delivers when all pass
5. **Commit** — `git commit -m "feat(oms): order sync improvements [PROJ-200]"`

> **When to use this over @magento-module-builder:** Use this pipeline for features, improvements, or fixes in existing modules. For building entirely new modules from scratch, use `@magento-module-builder` (Scenario H).

---

## What Fires When

### Instructions — triggered by file type

| File opened / edited | Instructions loaded |
|---|---|
| `.php` | `magento-php` + `security-php` |
| `.phtml` | `phtml-templates` |
| `.js` | `javascript-frontend` |
| `.xml` | `magento-xml` |
| Theme file | `theme-development` |

### Hook — triggered by AI edits

| AI action | Behaviour |
|---|---|
| Writes PHP code | `security-gate.sh` scans for dangerous patterns |
| Edits a protected path | Asks for confirmation before proceeding |

### Skills and Prompts — triggered by slash commands

| Command | What runs |
|---|---|
| `/review` | Quick review prompt |
| `/code-review` | 11-point checklist |
| `/security-audit` | 3-phase OWASP audit |
| `/performance-review` | Performance anti-pattern scan |
| `/elasticsearch` | Elasticsearch expertise loaded |
| `/module-documentation` | Docs generated + registry updated |
| `/phpunit` | Unit tests generated with mocks |
| `/accessibility` | WCAG 2.1 AA audit — 4-phase scan + remediation |
| `/jira-context` | Jira ticket context fetched explicitly |
| `/jira-comment` | Post a comment (or auto-summary) to a Jira ticket |
| `/pre-commit-check` | AI checks all changed files |

### Agents — triggered by @-mention

| Command | Agent |
|---|---|
| `@security-reviewer` | Read-only security audit agent |
| `@magento-architect` | Architecture advisor agent |
| `@magento-upgrade` | Upgrade planner — stack audit, dependency risk matrix, upgrade plan doc |
| `@magento-module-builder` | Module builder — requirements → plan → implementation → quality gates → delivery |
| `@magento-quality` | Quality gate runner — code review, performance, accessibility, PHPUnit, security, documentation with auto-fix |
| `@magento-implementation` | Plan implementer — architect plan → task list → changes in existing modules → quality gates → delivery |
