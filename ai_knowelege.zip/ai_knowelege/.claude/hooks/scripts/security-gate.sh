#!/bin/bash
# Security gate hook for AI coding assistants (Claude Code and VS Code Copilot)
# Runs before tool invocations to catch dangerous operations
# Receives JSON on stdin with tool info, outputs JSON decision

set -euo pipefail

INPUT=$(cat)
# Claude Code uses snake_case keys (tool_name); Copilot uses camelCase (toolName)
TOOL_NAME=$(echo "$INPUT" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(d.get('tool_name', d.get('toolName', '')))
" 2>/dev/null || echo "")

# Normalize to lowercase for case-insensitive matching (Claude sends 'Edit', Copilot sends 'insert_edit_into_file')
TOOL_NAME_LOWER=$(echo "$TOOL_NAME" | tr '[:upper:]' '[:lower:]')

# Only check edit/write/create operations
if [[ "$TOOL_NAME_LOWER" != "edit" && "$TOOL_NAME_LOWER" != "write" && "$TOOL_NAME_LOWER" != *"edit"* && "$TOOL_NAME_LOWER" != *"create"* && "$TOOL_NAME_LOWER" != *"replace"* ]]; then
    echo '{"continue": true}'
    exit 0
fi

# Extract file path from tool input (Claude uses snake_case, Copilot uses camelCase)
FILE_PATH=$(echo "$INPUT" | python3 -c "
import sys, json
d = json.load(sys.stdin)
inp = d.get('tool_input', d.get('toolInput', {}))
print(inp.get('file_path', inp.get('filePath', inp.get('path', ''))))
" 2>/dev/null || echo "")

# Block edits to auto-generated, runtime, or vendor-managed paths.
# These directories are either managed by Composer/Magento tooling or contain
# runtime data — direct edits would be overwritten or are never appropriate.
BLOCKED_PATHS=(
    "vendor/"          # Composer-managed dependencies
    "generated/"       # Magento-generated factories, proxies, interceptors
    "pub/static/"      # Compiled static assets (bin/magento setup:static-content:deploy)
    "pub/media/"       # User-uploaded media files
    "var/"             # Cache, logs, sessions, tmp — runtime only
    "node_modules/"    # npm/yarn dependencies
    ".github/hooks/"   # Protect the Copilot hooks config from self-modification
    ".claude/hooks/"   # Protect the Claude Code hooks config from self-modification
)

for pattern in "${BLOCKED_PATHS[@]}"; do
    if [[ "$FILE_PATH" == *${pattern}* ]]; then
        cat <<EOF
{
    "hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "ask",
        "permissionDecisionReason": "Attempting to edit protected path: $FILE_PATH. This directory should not normally be modified."
    }
}
EOF
        exit 0
    fi
done

# Check if the new content contains dangerous patterns (for PHP files)
if [[ "$FILE_PATH" == *.php ]]; then
    NEW_CONTENT=$(echo "$INPUT" | python3 -c "
import sys, json
d = json.load(sys.stdin)
inp = d.get('tool_input', d.get('toolInput', {}))
print(inp.get('new_string', inp.get('newString', inp.get('content', ''))))
" 2>/dev/null || echo "")

    DANGEROUS_PATTERNS=(
        "ObjectManager::getInstance"
        "eval("
        "shell_exec("
        "unserialize("
        '$_GET'
        '$_POST'
        '$_REQUEST'
    )

    for pattern in "${DANGEROUS_PATTERNS[@]}"; do
        if echo "$NEW_CONTENT" | grep -qF "$pattern" 2>/dev/null; then
            cat <<EOF
{
    "hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "ask",
        "permissionDecisionReason": "Code contains potentially dangerous pattern: $pattern. Please confirm this is intentional."
    }
}
EOF
            exit 0
        fi
    done
fi

echo '{"continue": true}'
exit 0
