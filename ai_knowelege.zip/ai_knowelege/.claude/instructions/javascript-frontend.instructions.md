---
description: "Use when editing JavaScript files in Magento 2 custom code. Covers RequireJS, Knockout.js, jQuery conventions, and XSS prevention. Applies to both app/ (standard) and modules/ (extension convention)."
applyTo: "app/**/*.js"
---

# Magento 2 JavaScript / Frontend Conventions

## RequireJS
- Define modules with `define(['dependency'], function(dep) { ... })` syntax
- Use `requirejs-config.js` to declare module mappings, mixins, and shims
- Reference Magento modules by their RequireJS alias (e.g., `jquery`, `ko`, `mage/url`, `Magento_Ui/js/lib/core/element/element`)
- NEVER load external scripts via `<script>` tags — use RequireJS deps

## Mixins (Preferred Extension Pattern)
- Extend existing JS components via mixins in `requirejs-config.js`:
  ```js
  config: { mixins: { 'Magento_Checkout/js/view/shipping': { 'Vendor_Module/js/view/shipping-mixin': true } } }
  ```
- Mixin function receives original component and returns extended version
- Prefer mixins over full file overrides for maintainability

## Knockout.js Templates (.html)
- Use `data-bind` attributes for Knockout bindings
- Custom components: register via `uiComponent` and layout XML
- Observe all dynamic properties: `this.myProperty = ko.observable(initialValue)`
- Use `$t('text')` for translations in templates (from `mage/translate`)

## jQuery
- Use Magento's jQuery widget factory for widgets: `$.widget('mage.widgetName', { ... })`
- Prefer jQuery UI widget pattern over raw jQuery plugins
- Use `$().trigger('contentUpdated')` after dynamic DOM changes to reinitialize bindings

## Security
- NEVER use `innerHTML` or jQuery `.html()` with unsanitized user input — use `.text()` or proper escaping
- When creating DOM elements dynamically, use `document.createElement()` + `innerText`/`setAttribute()` instead of `innerHTML` or `.html()` — this is the safest approach
- Sanitize user input before inserting into DOM
- Use `mage/url` for building URLs — never concatenate strings
- Avoid `eval()` and `new Function()` with dynamic input

### Knockout Template XSS Rules
Per the [Adobe XSS prevention guide](https://developer.adobe.com/commerce/php/development/security/cross-site-scripting/):
- When binding a UI component property as inner HTML via `data-bind="html: ..."` or `html="..."`, the property/function **must** use the `UnsanitizedHtml` suffix to signal it may contain HTML
  ```html
  <div data-bind="html: propUnsanitizedHtml"></div>
  <p html="returnUnsanitizedHtml()"></p>
  ```
- A static test enforces this naming convention — omitting the suffix causes a test failure

### UI Component Data Provider XSS Rules
- User-generated data passed from PHP data providers to UI components is rendered for component linking by default
- Disable template rendering for user data with `__disableTmpl` to prevent XSS:
  ```php
  $uiData['customer'] = $customer->getData();
  $uiData['__disableTmpl'] = ['customer' => true];
  ```

## Performance
- Lazy-load JS modules — use `deps` only for truly global scripts
- Avoid synchronous AJAX calls
- Use `domReady!` RequireJS plugin instead of `$(document).ready()`
- Minimize DOM queries — cache jQuery selections

## Code Style
- Use `'use strict';` in all modules
- camelCase for variables and functions, PascalCase for constructor functions
- JSDoc comments for public API functions
- 4 spaces indentation (matching Magento standard)
