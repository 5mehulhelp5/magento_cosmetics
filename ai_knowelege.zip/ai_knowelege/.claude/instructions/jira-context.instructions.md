---
description: "Fetch Jira ticket context from Jira DC REST API. Referenced by agents when a Jira ticket ID is detected in the conversation."
---

# Jira Ticket Context — Auto-Detection

When the user mentions Jira ticket IDs (pattern: `[A-Z][A-Z0-9]+-\d+`, e.g., `COS-1234`), automatically fetch ticket context before starting work.

## Detection

- Look for ticket ID patterns in the user's message: `COS-1234`, `COS-1234, COS-1235`, etc.
- Common prefixes in this project: `COS`
- Do NOT trigger on patterns that are clearly not Jira tickets (e.g., PHP class names, semver versions)

## Fetching

1. Read credentials from `.env` via terminal:
   ```sh
   JIRA_DC_URL=$(grep '^JIRA_DC_URL=' .env | cut -d'=' -f2- | tr -d '"' | sed 's:/*$::')
   JIRA_ACCESS_TOKEN=$(grep '^JIRA_ACCESS_TOKEN=' .env | cut -d'=' -f2- | tr -d '"')
   ```
2. Call the Jira REST API with a single request:
   ```sh
   curl -s -X POST "${JIRA_DC_URL}/rest/api/2/search" \
     -H "Authorization: Bearer ${JIRA_ACCESS_TOKEN}" \
     -H "Content-Type: application/json" \
     -d '{"jql": "key IN (TICKET1, TICKET2)", "fields": ["key", "summary", "status", "priority", "description", "issuelinks", "components", "labels"]}'
   ```
3. Extract from the JSON response: summary, description (condensed), acceptance criteria, status, priority, linked issues, mentioned modules/environments

## Usage

Provide the fetched context as background when:
- Implementing a feature referenced by a ticket
- Reviewing code for a ticket
- Debugging an issue described in a ticket

Do not block the workflow if the API call fails — note the error and proceed with whatever context is available.

Do not block the workflow if fetching fails — note the failure and proceed with whatever context is available.
