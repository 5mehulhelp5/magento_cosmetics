---
description: "Use when editing Magento 2 PHP module code. Covers DI, plugins, observers, repositories, and Magento PHP conventions. Applies to both app/code (standard) and modules/ (extension composer convention)."
applyTo: "app/**/*.php"
---

# Magento 2 PHP Module Development

## Module File Structure

Two conventions are used depending on the project setup:

### Convention 1: Standard app/code

Each module lives directly under `app/code/{Vendor}/{ModuleName}/`:

```
app/code/{Vendor}/{ModuleName}/
├── Api/                         # PHP classes exposed to the Service Contract / API layer
├── Block/                       # View classes (MVC) — prefer ViewModel over new Block classes
├── Console/                     # CLI commands (bin/magento)
├── Controller/                  # HTTP controllers (frontend and adminhtml)
├── Cron/                        # Cron job classes
├── CustomerData/                # Customer section (private content) data providers
├── etc/                         # Configuration: module.xml, di.xml, config.xml, system.xml, etc.
├── Helper/                      # Aggregated functionality (use sparingly — prefer ViewModel/service)
├── i18n/                        # Translation CSV files
├── Model/                       # Business logic, entities, data models
│   └── ResourceModel/           # Database interaction (CRUD)
│       └── {Entity}/
│           └── Collection       # Entity collection classes
├── Observer/                    # Event observer classes
├── Plugin/                      # Interceptor classes
├── Setup/                       # Install/upgrade schema and data scripts (legacy) or data patches
├── UI/                          # UI component data providers
├── view/                        # View files: layout XML, templates, web assets (JS/CSS/images)
├── ViewModel/                   # MVVM view models — preferred over Block for new code
└── registration.php             # Magento module registration
```

### Convention 2: Extension (composer package):

Each module lives under `modules/module-{module-name}/` as a self-contained composer package:

```
modules/module-{module-name}/
├── src/                         # All Magento module source code
│   ├── Api/                     # PHP classes exposed to the Service Contract / API layer
│   ├── Block/                   # View classes (MVC) — prefer ViewModel over new Block classes
│   ├── Console/                 # CLI commands (bin/magento)
│   ├── Controller/              # HTTP controllers (frontend and adminhtml)
│   ├── Cron/                    # Cron job classes
│   ├── CustomerData/            # Customer section (private content) data providers
│   ├── etc/                     # Configuration: module.xml, di.xml, config.xml, system.xml, etc.
│   ├── Helper/                  # Aggregated functionality (use sparingly — prefer ViewModel/service)
│   ├── i18n/                    # Translation CSV files
│   ├── Model/                   # Business logic, entities, data models
│   │   └── ResourceModel/       # Database interaction (CRUD)
│   │       └── {Entity}/
│   │           └── Collection   # Entity collection classes
│   ├── Observer/                # Event observer classes
│   ├── Plugin/                  # Interceptor classes
│   ├── Setup/                   # Install/upgrade schema and data scripts (legacy) or data patches
│   ├── UI/                      # UI component data providers
│   ├── view/                    # View files: layout XML, templates, web assets (JS/CSS/images)
│   ├── ViewModel/               # MVVM view models — preferred over Block for new code
│   └── registration.php         # Magento module registration
├── docs/                        # Module-level documentation
├── composer.json                # Package definition and dependencies
├── README.md                    # Module overview and usage
└── LICENSE_MAGE.txt            # License file
```

## Naming Conventions
- Module name: `{Vendor}_{ModuleName}` — naming must follow the [component naming](https://developer.adobe.com/commerce/php/development/build/component-name/) rules
- Standard layout root: `app/code/{Vendor}/{ModuleName}/`
- Extension layout root: `modules/module-{module-name}/src/` (composer package with `src/` wrapper)
- Registration: every module must have `registration.php` and `etc/module.xml`
- Class single responsibility — each class should have one clear purpose

## Dependency Injection
- Use constructor injection exclusively — never use ObjectManager directly
- Type-hint interfaces, not concrete classes
- Configure preferences and type arguments in `etc/di.xml`

## Plugins (Interceptors)
- Prefer plugins over class rewrites/preferences when modifying existing behavior
- Name convention: `before{Method}`, `around{Method}`, `after{Method}`
- Declare in `etc/di.xml` (or area-scoped: `etc/frontend/di.xml`, `etc/adminhtml/di.xml`)
- Use `sortOrder` to control plugin execution sequence
- Avoid plugins on `final` methods or classes
- Avoid plugins on `__construct` and `__destruct`
- Avoid around plugins unless necessary — prefer before/after for simplicity

## Observers
- Use event observers for cross-cutting concerns or when plugins are not suitable
- Declare in `etc/events.xml` (or area-scoped: `etc/frontend/events.xml`, `etc/adminhtml/events.xml`)
- Name convention: `{Vendor}_{Module}_Observer_{EventName}`
- Use `execute()` method to handle the event

## Repositories and Data Interfaces
- Use Repository pattern for data access and manipulation
- Define Data Interfaces for data transfer objects (DTOs)
- Use ResourceModel for direct database operations only when necessary (e.g., complex queries)
- Follow Magento's service contracts guidelines for module API design

## Code Standards
- Follow PSR-12 and Magento 2 coding standards
- Use strict types: `declare(strict_types=1);`
- Namespace pattern: `{Vendor}\{ModuleName}\{SubNamespace}`
- Always add return type declarations to methods
- Use typed properties (PHP 8.x)
- Avoid magic methods when typed alternatives exist
- Maximum method complexity: keep methods under ~20 lines, extract helpers for clarity
- Prefer early returns over deep nesting

## PHP File Conventions

### File structure order

1. `<?php` + blank line
2. `declare(strict_types=1);` + blank line
3. `namespace …;` + blank line
4. `use` statements — one per line, alphabetically sorted, no grouping blank lines
5. Class declaration

### Constants

Always declare the type explicitly (PHP 8.3+):

```php
private const string WEBSITE_CODE = 'pr';
private const int ROOT_CATEGORY_ID = 2;
```

### Constructor

- Use constructor property promotion (`private readonly …`)
- Trailing comma after the last parameter
- Body on its own line, never inline `{}`

```php
public function __construct(
    private readonly FooFactory $fooFactory,
    private readonly BarResource $barResource,
) {
}
```

### PHPDoc

- Add `@throws SomeException` on any method that can throw a checked exception (e.g. methods calling `ResourceModel::save()` which throws `AlreadyExistsException`)
- No other docblocks unless the type cannot be expressed in PHP syntax

```php
/**
 * @throws AlreadyExistsException
 */
public function apply(): self
```

### Imports

- Always import classes with `use` — never use fully-qualified class names (`\Magento\…`) inline in method signatures, type hints, or docblocks
- Import every exception referenced in `@throws`
- All `use` statements go in the imports block, alphabetically sorted

## SOLID Principles

### S — Single Responsibility
A class has one reason to change. Each class encapsulates a single concern.
- Keep domain logic, data access, and infrastructure in separate classes
- If a class needs many unrelated collaborators, extract responsibilities into dedicated classes

### O — Open-Closed
Open for extension, closed for modification.
- Define contracts with interfaces; add behavior by implementing new classes, not editing existing ones
- Replace `if ($type === 'x')` branching with polymorphism (strategy/decorator pattern)
- Never change existing method signatures to accommodate new behavior

### L — Liskov Substitution
A subclass must be substitutable for its parent without breaking behavior.
- Overriding methods must honor the parent's contract: same parameter types, return types, and exceptions
- If a child does not work in all contexts where the parent is used, redesign the hierarchy

### I — Interface Segregation
Clients must not depend on interfaces they don't use.
- Create small, focused interfaces (one purpose per interface)
- Split bloated interfaces into role-based ones; never force implementations to stub unused methods
- Inject only the interface(s) a class actually needs

### D — Dependency Inversion
Depend on abstractions, not concrete implementations.
- Constructor-inject dependencies as interfaces, never as concrete classes
- Never `new` a concrete dependency inside a class — use factories or DI container
- Program against interfaces so implementations are swappable without touching the consumer

## KISS Principle

Keep It Simple, Stupid — favor the simplest solution that solves the problem.
- Solve only the problem at hand; do not add patterns or abstractions speculatively
- Shallow nesting and clear names over clever one-liners or nested ternaries
- If a block of code is hard to read, rewrite it — complexity is a defect, not a feature

## Error Handling
- Throw specific exception types (`\Magento\Framework\Exception\LocalizedException`, `NoSuchEntityException`, `CouldNotSaveException`)
- Never catch `\Exception` silently — always log or re-throw
- Use `$this->logger->error()` for unexpected failures (inject `\Psr\Log\LoggerInterface`)

## Data Persistence
- Use Repository pattern with SearchCriteria for data access
- Use Data Interfaces for data transfer objects
- Use ResourceModel for direct DB operations only when necessary

## Performance Awareness
- Use collections with `addFieldToFilter()` and `setPageSize()` — never load full collections
- Avoid loading models inside loops — batch with SearchCriteria
- Use `afterSave`/`afterDelete` plugins sparingly — they run on every save
- Prefer `around` plugins only when before/after cannot achieve the goal
- Ensure `around` plugins return the correct types of data
- Use factories or repositories to create models inside loop cycles — isolate data to prevent leaking between iterations (GDPR concern)

## Completeness Checks
- Is the module enable/disable-able by configuration? Does all code behave correctly in both states?
- Configuration must be retrieved at the lowest possible level (store view > website > global) matching the scope defined in `system.xml`
- ACLs must be defined for any new admin functionality
- Ensure PhpDocs are clear; no commented-out or debug code in production
- No `var_dump()`, `print_r()`, `debug_backtrace()` in non-dev code

## Context: Where to search
- Custom code: `app/` (this directory)
- NEVER reference `vendor/` unless specifically asked about a third-party package
