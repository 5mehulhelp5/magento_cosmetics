---
description: "Use when editing Magento 2 XML configuration files — di.xml, system.xml, module.xml, layout XML, routes, events, crontab. Covers schema and structure conventions. Applies to both app/ (standard) and modules/ (extension convention)."
applyTo: "app/**/*.xml"
---

# Magento 2 XML Configuration

## File Locations
- `etc/module.xml` — Module declaration and dependencies
- `etc/di.xml` — Dependency injection (global scope)
- `etc/frontend/di.xml` — Frontend-scoped DI
- `etc/adminhtml/di.xml` — Admin-scoped DI
- `etc/adminhtml/system.xml` — System configuration fields
- `etc/config.xml` — Default configuration values
- `etc/events.xml` — Event observers
- `etc/crontab.xml` — Cron job definitions
- `view/frontend/layout/*.xml` — Frontend layout handles
- `view/adminhtml/layout/*.xml` — Admin layout handles

## Conventions
- Always include `xsi:noNamespaceSchemaLocation` URN references
- Use `sequence` in `module.xml` to declare module load order
- Layout XML: use `referenceBlock`/`referenceContainer` to modify existing layouts
- Avoid `<preference>` in di.xml when a plugin would suffice

## Layout XML Best Practices
Per the [Adobe theme development best practices](https://developer.adobe.com/commerce/frontend-core/guide/best-practices):
- **Prefer layout XML changes over PHTML overrides** — use `.xml` layout instructions instead of customizing `.phtml` templates when possible
- Use `<move>` to reposition blocks or containers
- Use `<referenceBlock>/<referenceContainer>` with `remove="true"` or `display="false"` to hide elements
- Use `<referenceContainer>` to change HTML tag or CSS class on existing containers
- Use `ifconfig` on blocks to conditionally render based on system configuration

## Cacheable Blocks (Critical Performance Rule)
Per the [Adobe caching guide](https://developer.adobe.com/commerce/frontend-core/guide/caching):
- Setting `cacheable="false"` on **any** block disables Full Page Cache (FPC) for the **entire page**
- **NEVER** set `cacheable="false"` on content pages (catalog, product, CMS) — severe performance impact
- Only use `cacheable="false"` when the block truly requires non-cached data (e.g., checkout, compare)
- Consider private content (client-side via `customerData` sections) instead of making blocks uncacheable

## System Configuration (system.xml)
- Configuration scope (store view / website / global) must match how the value is retrieved in code
- Configuration retrieval must happen at the lowest possible level
- Always set validation rules, data types, and default values
- Sensitive config fields must use `<backend_model>Magento\Config\Model\Config\Backend\Encrypted</backend_model>`
- All configuration should be enable/disable-able when appropriate
