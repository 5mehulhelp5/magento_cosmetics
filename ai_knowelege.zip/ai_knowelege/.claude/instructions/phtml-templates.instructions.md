---
description: "Use when editing PHTML template files in Magento 2 custom code. Covers XSS prevention, output escaping, and template best practices. Applies to both app/ (standard) and modules/ (extension convention)."
applyTo: "app/**/*.phtml"
---

# Magento 2 PHTML Template Security & Conventions

## Output Escaping (Mandatory)
Per the [Adobe XSS prevention guide](https://developer.adobe.com/commerce/php/development/security/cross-site-scripting/):
the general rule is **do not trust dynamic values**. Every variable output MUST be escaped using the `$escaper` local variable (available in all `.phtml` templates via `\Magento\Framework\Escaper`).

### Escaper Method Reference

| Context | Method | Example |
|---------|--------|---------|
| HTML tag content (no HTML allowed) | `escapeHtml($value)` | `<span><?= $escaper->escapeHtml($block->getLabel()) ?></span>` |
| HTML tag content (some tags allowed) | `escapeHtml($value, ['a', 'br', 'p', …])` | `<?= $escaper->escapeHtml($text, ['a']) ?>` |
| HTML attribute value | `escapeHtmlAttr($value)` | `<div class="<?= $escaper->escapeHtmlAttr($class) ?>">` |
| JSON inside an HTML attribute | `escapeHtmlAttr($json)` | `<div data-bind='settings: <?= $escaper->escapeHtmlAttr($myJson) ?>'></div>` |
| URL in `href`/`src` attributes | `escapeUrl($value)` | `<a href="<?= $escaper->escapeUrl($url) ?>">` |
| Non-URL HTML attribute used by JS | `escapeHtmlAttr($value)` | `<div data-url="<?= $escaper->escapeHtmlAttr($url) ?>">` |
| JavaScript string inside `<script>` | `escapeJs($value)` | `let name = "<?= $escaper->escapeJs($name) ?>";` |
| JS variable name inside `<script>` | `escapeJs($value)` | `let <?= $escaper->escapeJs($var) ?> = true;` |
| JS inside HTML event attribute | `escapeHtmlAttr` wrapping `escapeJs` | `onclick="<?= $escaper->escapeHtmlAttr('handler("' . $escaper->escapeJs($str) . '")') ?>"` |
| CSS value | `escapeCss($value)` | `style="color: <?= $escaper->escapeCss($color) ?>"` |

### Allowed Tags in `escapeHtml()`
When passing an allowed-tags array (e.g., `['a', 'br', 'strong']`), only these attributes are preserved: `id`, `class`, `href`, `style`, `title`. All other attributes are stripped. The following tags are **never** allowed regardless: `embed`, `iframe`, `video`, `source`, `object`, `audio`, `script`, `img`.

### When Escaping Is NOT Required
- Methods whose name contains "Html" (e.g., `$block->getTitleHtml()`, `$block->getHtmlTitle()`) — data is pre-escaped
- Type casting: `<?= (int)$var ?>`, `<?= (bool)$var ?>`
- `count()`: `<?= count($items) ?>`
- Literal strings in single quotes: `<?= 'some text' ?>`
- Literal strings in double quotes without variables: `<?= "some text" ?>`
- JSON inside a `<script>` tag (no HTML context): `<script>let settings = <?= $myJson ?></script>`
- Use `/* @noEscape */` comment before output **only** when you have verified the value is safe — this suppresses the static test

### Static Test
Use `Magento2.Security.XssTemplate` sniff from the [Magento Coding Standard](https://github.com/magento/magento-coding-standard) to detect unescaped output in templates. The sniff flags any `echo`/`<?=` that does not match the safe patterns above.

## Forbidden in Templates
- `$block->escapeHtml()` — deprecated, use `$escaper->escapeHtml()` instead  
- `echo $variable;` without escaping — always wrap in escaper
- `ObjectManager::getInstance()` — never in templates
- Complex business logic — keep in Block/ViewModel classes, templates only display
- `<?= __('text') ?>` used as escaping — `__()` does NOT escape, wrap: `$escaper->escapeHtml(__('text'))`

## Template Conventions
- Use `/** @var \Vendor\Module\Block\ClassName $block */` phpdoc for IDE support
- Use ViewModels over Block classes for new code: `$viewModel = $block->getData('viewModel')`
- Short echo syntax: `<?= ... ?>` (not `<?php echo ... ?>`)
- Keep templates lean — delegate logic to ViewModel/Block PHP classes
- Use `$block->getUrl('route/path')` for URL generation, never hardcode paths
- **Always keep text translatable**: wrap in `__()` — e.g., `<?= $escaper->escapeHtml(__('Click to download')) ?>`
- **Prefer layout XML changes over template overrides** — use `.xml` instructions (`<move>`, `<referenceBlock>`, etc.) where possible instead of duplicating templates
- Change wording via CSV translation dictionaries, not by overriding templates
- Reuse existing markup and design patterns from default templates (use template hints to locate them)

## Layout XML Integration
- Templates are assigned via layout XML `template` attribute
- Use `arguments` in layout XML to inject ViewModels: `<argument name="viewModel" xsi:type="object">Vendor\Module\ViewModel\ClassName</argument>`
- Setting `cacheable="false"` on a block disables FPC for the **entire page** — only use when necessary, never on content pages (catalog, product, CMS)
