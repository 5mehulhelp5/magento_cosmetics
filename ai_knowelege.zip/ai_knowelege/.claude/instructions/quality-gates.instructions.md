---
description: "Quality gate process for Magento 2 module delivery. Referenced by magento-implementation and magento-module-builder agents before delegating to @magento-quality."
---

# Quality Gate Process

Before delegating to `@magento-quality`, run these Magento validation commands when applicable:

1. Run `bin/magento setup:upgrade` **if configuration or DB schema changed** (e.g. `etc/module.xml`, `etc/config.xml`, `etc/db_schema.xml`, `db_schema_whitelist.json`, data/schema patches).
2. Run `bin/magento setup:di:compile` **if DI wiring or class signatures changed** (e.g. constructor changes, `di.xml` updates, new preferences/plugins/virtual types, method declaration changes affecting generated code).
3. Treat both commands as compilation/installation safety checks. If either fails, fix the issue and re-run until it passes before continuing.

Delegate to `@magento-quality` (via agent tool) to run all quality gates against the target module. The quality agent will:

1. Run each gate: Code Review → Performance Review → Accessibility → PHPUnit Tests → Security Audit → Module Documentation
2. Auto-fix issues and re-run until each gate passes (max 3 iterations per gate before escalating to user)
3. Return a pass/fail checklist
