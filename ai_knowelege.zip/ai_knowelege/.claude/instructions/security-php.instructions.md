---
description: "Use when editing PHP files in Magento 2 custom code. Enforces OWASP Top 10 security rules — injection prevention, XSS, CSRF, access control, cryptographic safety. Applies to both app/ (standard) and modules/ (extension convention)."
applyTo: "app/**/*.php"
---

# PHP Security Rules (OWASP Top 10 for Magento 2)

## Injection Prevention (A03:2021)
- NEVER concatenate user input into SQL — use parameter binding via `SearchCriteriaBuilder`, `Select::where()` with bind params, or `$connection->quoteInto()`
- NEVER pass unsanitized input to `shell_exec()`, `exec()`, `system()`, `passthru()`, `proc_open()`, or backtick operator
- NEVER use `eval()`, `assert()` with string arguments, `create_function()`, or `preg_replace()` with `/e` modifier
- Use `$escaper->escapeHtml()`, `$escaper->escapeUrl()`, `$escaper->escapeJs()` for output encoding
- Validate all input against expected types using PHP type declarations and `filter_var()`

## Input Processing (XSS Prevention)
Per the [Adobe XSS prevention guide](https://developer.adobe.com/commerce/php/development/security/cross-site-scripting/):
- Validate/sanitize values as close as possible to the view context, not at the input boundary
- Do not strip control characters (`<`, `>`) from user input prematurely — data may be consumed by non-HTML contexts (e.g., REST API) where those characters are harmless
- Escape at output time using the appropriate `$escaper` method for the context (see PHTML template instructions)
- All request data must be treated as potentially malicious: form fields, headers, URIs, query parameters, cookies

## Cross-Site Scripting — XSS (A07:2021)
- All output in templates MUST be escaped — use `$escaper->escapeHtml()` for HTML context
- Use `$escaper->escapeHtmlAttr()` for HTML attribute values
- Use `$escaper->escapeJs()` for JavaScript context, `$escaper->escapeUrl()` for URL context
- Use `$escaper->escapeCss()` for CSS context
- NEVER use `__()` translation function as an escaping mechanism — it does NOT escape

## Broken Access Control (A01:2021)
- Always check ACL resources in admin controllers: `const ADMIN_RESOURCE = 'Vendor_Module::resource';`
- Validate customer session and ownership before returning data in frontend controllers
- Use `$this->_authorization->isAllowed()` or `isAllowed()` checks for admin operations
- Never expose internal IDs in URLs without authorization checks

## Cryptographic Failures (A02:2021)
- Use `\Magento\Framework\Encryption\EncryptorInterface` for sensitive data encryption
- NEVER store passwords in plain text — use Magento's password hashing
- NEVER hardcode API keys, tokens, or credentials — use `env.php` or encrypted config
- Use `\Magento\Framework\Math\Random` for generating tokens, nonces

## Security Misconfiguration (A05:2021)
- NEVER expose stack traces or detailed errors to end users — use Magento's exception handling
- NEVER log sensitive data (passwords, tokens, full credit card numbers)
- Set appropriate HTTP security headers via controller responses

## CSRF Protection (A01:2021)
- All POST/PUT/DELETE form submissions MUST include form key validation
- Use `$this->formKeyValidator->validate($request)` in controllers
- Admin controllers: extend `\Magento\Backend\App\Action` which handles CSRF automatically
- API endpoints: rely on OAuth/token authentication instead of form keys

## Insecure Deserialization (A08:2021)
- NEVER use `unserialize()` on untrusted data — use `\Magento\Framework\Serialize\Serializer\Json`
- Prefer JSON serialization over PHP serialization

## Server-Side Request Forgery — SSRF (A10:2021)
- Validate and whitelist URLs before making HTTP requests
- Do not allow user-controlled input to determine request destinations without validation
- Use `\Magento\Framework\HTTP\Client\Curl` with validated URLs

## Forbidden Patterns (auto-review triggers)
These patterns should NEVER appear in new code:
- `ObjectManager::getInstance()` — use constructor DI
- `$_GET`, `$_POST`, `$_REQUEST`, `$_SERVER` — use `RequestInterface`
- `echo`, `print` outside of templates — use proper response objects
- `file_get_contents()` with remote URLs — use `\Magento\Framework\HTTP\Client\Curl`
- `md5()`, `sha1()` for security purposes — use `password_hash()` or Magento's encryptor
