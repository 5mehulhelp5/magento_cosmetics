---
description: "Use when editing theme files — LESS/CSS, RequireJS, Knockout templates, layout overrides in theme directories. Applies to both app/design (standard) and modules/theme-* (extension composer convention)."
applyTo: "{app/design/**,modules/theme-*/**}"
---

# Magento 2 Theme Development

## Theme File Structure
Per the [Adobe Commerce theme structure guide](https://developer.adobe.com/commerce/frontend-core/guide/themes/structure/):

Two conventions are used depending on the project setup:

### Convention 1: Standard app/design

Theme lives under `app/design/<area>/<Vendor>/<theme>/`:
- Storefront themes: `app/design/frontend/<Vendor>/<theme>/`
- Admin themes: `app/design/adminhtml/<Vendor>/<theme>/`

```
app/design/<area>/<Vendor>/<theme>/
├── <Vendor>_<Module>/       # Module-scoped overrides
│   ├── web/
│   │   └── css/source/      # Module-specific LESS overrides
│   ├── layout/
│   │   └── override/        # Layout override XML files
│   └── templates/           # PHTML template overrides
├── etc/
│   └── view.xml             # Image types/sizes configuration
├── i18n/                    # Translation CSV dictionaries
├── media/                   # Theme preview images
├── web/
│   ├── css/
│   │   └── source/          # Theme LESS files (_theme.less, _extend.less)
│   ├── fonts/               # Custom font files
│   ├── images/              # Static images
│   └── js/                  # JavaScript files
├── composer.json
├── registration.php
└── theme.xml
```

### Convention 2: Extension (composer package)

Theme lives as a self-contained composer package under `modules/theme-<Vendor>-<theme>/`:

```
modules/theme-<Vendor>-<theme>/
├── src/                         # All theme source files
│   ├── <Vendor>_<Module>/       # Module-scoped overrides
│   │   ├── web/
│   │   │   └── css/source/      # Module-specific LESS overrides
│   │   ├── layout/
│   │   │   └── override/        # Layout override XML files
│   │   └── templates/           # PHTML template overrides
│   ├── etc/
│   │   └── view.xml             # Image types/sizes configuration
│   ├── i18n/                    # Translation CSV dictionaries
│   ├── media/                   # Theme preview images
│   ├── web/
│   │   ├── css/
│   │   │   └── source/          # Theme LESS files (_theme.less, _extend.less)
│   │   ├── fonts/               # Custom font files
│   │   ├── images/              # Static images
│   │   └── js/                  # JavaScript files
│   ├── registration.php
│   └── theme.xml
├── composer.json
└── README.md
```

### Static vs Dynamic View Files
- **Static files** (`media/`, `web/css/` except `source/`, `web/fonts/`, `web/images/`, `web/js/`) — served as-is to the browser
- **Dynamic files** (`.less` in `source/`, templates, layouts) — processed server-side before delivery
- Static files are published to `pub/static/frontend/<Vendor>/<theme>/<locale>/`

## Theme Hierarchy
- Base themes extend Magento Blank or Luma
- Child themes inherit everything from the parent — only override what differs
- Override templates by replicating the module path structure under the theme: `<theme_dir>/<Vendor>_<Module>/templates/`

## Best Practices
Per the [Adobe theme development best practices](https://developer.adobe.com/commerce/frontend-core/guide/best-practices):

### Styles
- **Extend default styles instead of overriding them** — put customizations in `_extend.less` or `_theme.less` instead of overriding parent LESS files
- Add styles to separate LESS files instead of one monolith — easier to track and debug
- Don't repeat styles — create a class or mixin and reuse it
- Style custom modules inside the module, not in the theme — styles only load when the module is active:
  - Convention 1: `app/code/Company/Module/view/frontend/web/css/source/_module.less`
  - Convention 2: `modules/module-{module-name}/src/view/frontend/web/css/source/_module.less`
- Use component-based LESS: import via `_components.less` for new or extended components
- Use the [CSS critical path](https://developer.adobe.com/commerce/frontend-core/guide/css/critical-path/) to render above-the-fold content faster
- Use mobile-first approach when inheriting Blank or Luma

### Templates & Layouts
- **Prefer layout XML changes over PHTML overrides** — use `.xml` instructions (`<move>`, `<referenceBlock>`, `<referenceContainer>`) when possible
- Reuse existing markup patterns from default `.phtml` templates (use template hints to find them)
- Use `etc/view.xml` to change image types or sizes instead of template changes
- Change wording via [CSV translation dictionaries](https://developer.adobe.com/commerce/frontend-core/guide/translations/dictionary), not by overriding templates

### General
- Keep text translatable: `<?= __('Click to download') ?>`
- Follow [coding standards](https://developer.adobe.com/commerce/php/coding-standards/) for both back-end and front-end
- Use `requirejs-config.js` for JS module mappings and mixins

## Caching in Theme Development
Per the [Adobe caching guide](https://developer.adobe.com/commerce/frontend-core/guide/caching):
- When working on styles only, clean preprocessed files (`var/view_preprocessed/` and `pub/static/`) — no need to flush full cache
- Use `grunt clean <theme>` or manually clear `pub/static` and `var/view_preprocessed` directories
- `cacheable="false"` on any block disables FPC for the **entire page** — never use on content pages
- Distinguish public content (server-cached, shared) from private content (client-side, per-user)
- Only HTTP GET and HEAD requests are cacheable
