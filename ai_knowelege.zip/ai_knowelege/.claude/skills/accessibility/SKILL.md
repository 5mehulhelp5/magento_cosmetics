---
name: accessibility
description: "WCAG 2.1 AA accessibility audit and remediation for Magento 2 modules. Use when reviewing templates for accessibility, auditing ARIA usage, checking color contrast, keyboard navigation, form labels, focus management, screen reader support, or ensuring WCAG compliance in PHTML, Knockout.js, LESS, and layout XML."
argument-hint: "Path to module, template, theme, or describe the accessibility concern"
---

# Magento 2 Accessibility Audit — WCAG 2.1 AA

## When to Use
- Auditing a module or theme for WCAG 2.1 AA compliance
- Reviewing templates (PHTML, Knockout.js `.html`) for accessibility issues
- Checking forms, modals, navigation, or interactive widgets for keyboard/screen reader support
- Verifying color contrast and text alternatives
- Remediating accessibility findings before release
- Writing new frontend code that must meet accessibility standards

## WCAG 2.1 AA Requirements Overview

WCAG 2.1 AA is organized under four principles — **Perceivable**, **Operable**, **Understandable**, **Robust** (POUR). Each section below maps audit checks to specific WCAG success criteria.

---

## Audit Procedure

> **Efficiency**: Gather all target files (PHTML, Knockout templates, LESS/CSS, JS) in a single exploration pass before analysing — do not read files one at a time in a loop.

### Phase 1: Automated Pattern Scan

Search the target code for accessibility anti-patterns. For each category, search for the listed patterns and flag matches.

#### 1.1 Images & Non-Text Content (SC 1.1.1)
Search patterns:
- `<img` without `alt` attribute
- `<img` with empty `alt=""` on informative images (not decorative)
- `<svg` without `aria-hidden="true"` (decorative) or `role="img"` + `aria-label`/`<title>` (informative)
- `<input type="image"` without `alt`
- `<area` without `alt`
- CSS `background-image` used for informative content without text alternative

**Rule**: Every `<img>` must have an `alt` attribute. Decorative images use `alt=""`. Informative images need descriptive alt text. Icon-only SVGs used as buttons need `aria-label`.

#### 1.2 Form Controls & Labels (SC 1.3.1, 4.1.2)
Search patterns:
- `<input` without associated `<label for="">` or `aria-label`/`aria-labelledby`
- `<select` without associated label
- `<textarea` without associated label
- `<fieldset` without `<legend>`
- `<input type="checkbox"` or `type="radio"` without label
- `placeholder` used as sole label (placeholder is NOT a label)
- Knockout template `<input data-bind=` without label binding

**Rule**: Every form control must have a programmatically associated label. Use `<label for="id">`, `aria-label`, or `aria-labelledby`. Group related controls (radio buttons, checkboxes) in `<fieldset>` with `<legend>`.

#### 1.3 Semantic Structure (SC 1.3.1, 1.3.2)
Search patterns:
- `<div` or `<span` used as button/link (`onclick` without `role="button"` and `tabindex`)
- Heading levels skipped (e.g., `<h1>` → `<h3>` with no `<h2>`)
- `<b>` or `<i>` used for emphasis instead of `<strong>` / `<em>`
- `<table` without `<th>` or `<caption>`
- Data tables without `scope="col"` or `scope="row"` on `<th>`
- Lists of items not using `<ul>`, `<ol>`, `<li>`
- Layout tables used for non-tabular content

**Rule**: Use semantic HTML elements. Headings must be hierarchical. Tables must have headers. Interactive elements must be natively focusable or have proper ARIA roles.

#### 1.4 ARIA Usage (SC 4.1.2)
Search patterns:
- `role="button"` without `tabindex="0"` and keyboard handler
- `aria-labelledby` referencing non-existent `id`
- `aria-describedby` referencing non-existent `id`
- `aria-controls` referencing non-existent `id`
- `aria-expanded` without toggling logic
- Redundant ARIA: `role="button"` on `<button>`, `role="link"` on `<a>`
- `aria-hidden="true"` on focusable elements (creates a11y trap)
- Missing `aria-live` on dynamically updated regions (cart count, messages, AJAX content)

**Rule**: Follow the [first rule of ARIA](https://www.w3.org/TR/using-aria/#firstrule) — prefer native HTML over ARIA. When ARIA is needed, ensure roles, states, and properties are correct and complete.

#### 1.5 Keyboard Accessibility (SC 2.1.1, 2.1.2)
Search patterns:
- `onclick` without corresponding `onkeydown`/`onkeypress`/`onkeyup` handler
- `tabindex` values greater than `0` (disrupts natural tab order)
- Custom widgets without keyboard support (`Enter`/`Space` for activation, `Escape` to dismiss)
- Modal/dialog without focus trap (focus escapes to background)
- `mousedown`/`mouseover`/`mouseout` without keyboard equivalents
- CSS `outline: none` or `outline: 0` without visible focus replacement
- `:hover` styles without corresponding `:focus` styles
- `user-select: none` on interactive text

**Rule**: All functionality must be operable via keyboard. Tab order must be logical. Custom widgets must support expected keyboard patterns (arrow keys for menus, Escape for modals, Enter/Space for buttons).

#### 1.6 Focus Management (SC 2.4.3, 2.4.7, 3.2.1)
Search patterns:
- Modal opening without moving focus to modal
- Modal closing without returning focus to trigger element
- Dynamic content inserted without focus management
- Page navigation without focus reset
- Missing visible focus indicator (`:focus` styles)
- `autofocus` used on elements that change context unexpectedly

**Rule**: Focus must be visible at all times. When modals open, focus moves into them. When modals close, focus returns to the trigger. Dynamically loaded content should manage focus appropriately.

#### 1.7 Color & Contrast (SC 1.4.3, 1.4.1, 1.4.11)
Search patterns in LESS/CSS:
- Text color paired with background where contrast ratio < 4.5:1 (normal text) or < 3:1 (large text 18px+/14px bold+)
- Information conveyed by color alone (e.g., error indicated only by red text, no icon/text)
- Non-text UI components (borders, icons, focus indicators) with contrast < 3:1 against background
- Disabled styles that still need to be perceivable

**Rule**: Normal text must have 4.5:1 contrast ratio. Large text (18px+ or 14px+ bold) must have 3:1. UI components and graphical objects must have 3:1. Never rely on color alone to convey information.

#### 1.8 Text Resize & Reflow (SC 1.4.4, 1.4.10)
Search patterns in LESS/CSS:
- Fixed pixel sizes for text (`font-size: 14px`) — prefer `rem`/`em`
- `overflow: hidden` on containers that may contain text
- Fixed-width containers that prevent text reflow at 320px viewport
- `max-width` or `max-height` with `overflow: hidden` on text containers

**Rule**: Text must be resizable up to 200% without loss of content. Content must reflow at 320px CSS width (equivalent to 400% zoom on 1280px viewport) without horizontal scrolling.

#### 1.9 Link & Button Purpose (SC 2.4.4, 2.4.9)
Search patterns:
- Links with text "click here", "read more", "here", "more" without `aria-label` providing full context
- Multiple links with same text but different destinations
- Icon-only links/buttons without `aria-label` or `sr-only` text
- `<a>` without `href` (not focusable) used as interactive element
- Empty `<a>` or `<button>` (no text content or aria-label)

**Rule**: Link and button text must describe purpose. If visible text is generic, add `aria-label` or visually-hidden text. Every interactive element must have an accessible name.

#### 1.10 Language (SC 3.1.1, 3.1.2)
Search patterns:
- `<html` without `lang` attribute (check layout XML head)
- Inline content in different language without `lang` attribute on wrapper

**Rule**: Page must declare language via `lang` attribute. Inline text in a different language should have `lang` set on its container.

#### 1.11 Error Identification & Suggestions (SC 3.3.1, 3.3.2, 3.3.3)
Search patterns:
- Form validation showing errors without `aria-describedby` linking to error message
- Error messages not associated with the relevant input
- Required fields without `aria-required="true"` or `required` attribute
- Error messages conveyed only by color change
- Missing input instructions for expected format (e.g., date, phone)

**Rule**: Errors must be identified in text and associated with the field. Required fields must be programmatically indicated. Suggestions for correction should be provided where possible.

#### 1.12 Page Titles & Landmarks (SC 2.4.1, 2.4.2)
Search patterns:
- Pages without unique `<title>` (check layout XML `<title>`)
- Missing skip-to-content link
- Missing landmark roles: `<main>`, `<nav>`, `<header>`, `<footer>` (or equivalent ARIA roles)
- Multiple `<main>` elements
- `<nav>` without `aria-label` when multiple nav regions exist

**Rule**: Every page must have a descriptive `<title>`. Provide a skip-to-main-content link. Use HTML5 landmark elements. Label duplicate landmarks.

---

### Phase 2: Component-Specific Checks

#### Modals / Dialogs
- [ ] `role="dialog"` and `aria-modal="true"` present
- [ ] `aria-labelledby` references modal title
- [ ] Focus trapped inside modal while open
- [ ] `Escape` key closes modal
- [ ] Focus returns to trigger on close
- [ ] Background content has `aria-hidden="true"` or `inert` while modal is open

#### Dropdown Menus / Mega-Menus
- [ ] Trigger has `aria-expanded` toggling `true`/`false`
- [ ] `aria-haspopup="true"` on trigger
- [ ] Arrow keys navigate menu items
- [ ] `Escape` closes menu and returns focus to trigger
- [ ] Menu items have `role="menuitem"` when using ARIA menu pattern

#### Tabs
- [ ] Tab list uses `role="tablist"`, tabs use `role="tab"`, panels use `role="tabpanel"`
- [ ] `aria-selected="true"` on active tab
- [ ] `aria-controls` links tab to its panel
- [ ] Arrow keys navigate between tabs
- [ ] `tabindex="-1"` on inactive tabs, `tabindex="0"` on active tab

#### Accordions
- [ ] Trigger is `<button>` (or has `role="button"`)
- [ ] `aria-expanded` toggles on trigger
- [ ] `aria-controls` references content panel `id`
- [ ] Content panel has appropriate `role` if needed
- [ ] `Enter` and `Space` toggle the section

#### Data Tables
- [ ] `<caption>` or `aria-label` describes the table
- [ ] `<th>` with `scope="col"` or `scope="row"`
- [ ] Complex tables use `headers` attribute linking `<td>` to `<th>` ids
- [ ] Sortable columns indicate sort state with `aria-sort`

#### Notifications / Messages (AJAX)
- [ ] Success/error messages use `aria-live="polite"` or `role="status"`
- [ ] Urgent alerts use `aria-live="assertive"` or `role="alert"`
- [ ] Messages added to existing live region container (not dynamically created)
- [ ] Cart count/mini-cart updates announce changes

#### Carousel / Slider
- [ ] Pause/stop control available
- [ ] Current slide indicated (`aria-current` or equivalent)
- [ ] Navigation controls (prev/next/dots) labeled
- [ ] Auto-rotation respects `prefers-reduced-motion`

---

### Phase 3: Knockout.js Template Checks

Magento 2 Knockout templates (`.html` files) have specific accessibility patterns:

- [ ] `data-bind="text:"` used instead of `html:` for text content (XSS + a11y)
- [ ] `data-bind="attr: { 'aria-label': label }"` for dynamic labels
- [ ] `data-bind="css: { 'active': isActive }"` paired with `aria-selected` or `aria-current`
- [ ] `$t('text')` used for all translatable strings
- [ ] `<!-- ko if: -->` sections don't break ARIA relationships when conditionally rendered
- [ ] `data-bind="visible:"` toggles `aria-hidden` and `tabindex` to match
- [ ] Dynamic components announce updates via `aria-live` regions

---

### Phase 4: LESS/CSS Accessibility Checks

- [ ] `:focus` styles are at least as visible as `:hover` styles
- [ ] Focus indicators meet 3:1 contrast against surrounding content
- [ ] `@media (prefers-reduced-motion: reduce)` disables/reduces animation
- [ ] `@media (prefers-contrast: more)` considered for high-contrast mode
- [ ] `.sr-only` / `.visually-hidden` class available and used correctly:
  ```less
  .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
  }
  ```
- [ ] No `display: none` or `visibility: hidden` on content that should remain accessible to screen readers (use `.sr-only` instead)
- [ ] Text spacing overridable (no `!important` on `line-height`, `letter-spacing`, `word-spacing`)

---

## Remediation Patterns

### Adding Screen Reader Only Text
```phtml
<button class="action action-delete" title="<?= $escaper->escapeHtmlAttr(__('Remove Item')) ?>">
    <span class="sr-only"><?= $escaper->escapeHtml(__('Remove %1', $productName)) ?></span>
    <svg aria-hidden="true"><!-- icon --></svg>
</button>
```

### Labeling Icon-Only Buttons
```phtml
<button type="button"
        aria-label="<?= $escaper->escapeHtmlAttr(__('Close')) ?>"
        class="action-close">
    <svg aria-hidden="true" focusable="false"><!-- close icon --></svg>
</button>
```

### Accessible Modal Pattern
```phtml
<div role="dialog"
     aria-modal="true"
     aria-labelledby="modal-title-<?= $escaper->escapeHtmlAttr($modalId) ?>"
     class="modal-content">
    <h2 id="modal-title-<?= $escaper->escapeHtmlAttr($modalId) ?>">
        <?= $escaper->escapeHtml(__('Modal Title')) ?>
    </h2>
    <!-- modal body -->
    <button type="button"
            class="action-close"
            aria-label="<?= $escaper->escapeHtmlAttr(__('Close')) ?>">
    </button>
</div>
```

### Accessible Form Field
```phtml
<div class="field required">
    <label class="label" for="email">
        <span><?= $escaper->escapeHtml(__('Email Address')) ?></span>
    </label>
    <div class="control">
        <input type="email"
               id="email"
               name="email"
               required
               aria-required="true"
               aria-describedby="email-error"
               class="input-text"
               autocomplete="email" />
        <div id="email-error" class="mage-error" role="alert" style="display:none;"></div>
    </div>
</div>
```

### Accessible Data Table
```phtml
<table class="data table" aria-label="<?= $escaper->escapeHtmlAttr(__('Order Items')) ?>">
    <thead>
        <tr>
            <th scope="col"><?= $escaper->escapeHtml(__('Product Name')) ?></th>
            <th scope="col"><?= $escaper->escapeHtml(__('SKU')) ?></th>
            <th scope="col"><?= $escaper->escapeHtml(__('Qty')) ?></th>
            <th scope="col"><?= $escaper->escapeHtml(__('Price')) ?></th>
        </tr>
    </thead>
    <tbody>
        <!-- rows -->
    </tbody>
</table>
```

### Live Region for AJAX Updates
```html
<!-- In Knockout template -->
<div aria-live="polite" aria-atomic="true" class="sr-only"
     data-bind="text: statusMessage">
</div>
```

### Skip Navigation Link
```phtml
<a class="action skip sr-only sr-only--focusable"
   href="#maincontent">
    <?= $escaper->escapeHtml(__('Skip to main content')) ?>
</a>
```

### Focus-Visible CSS
```less
// Ensure visible focus for keyboard users
:focus-visible {
    outline: 2px solid @focus-color;
    outline-offset: 2px;
}

// Remove default outline only when :focus-visible is supported
:focus:not(:focus-visible) {
    outline: none;
}
```

### Reduced Motion
```less
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
    }
}
```

---

## Output Format

```
## Accessibility Audit: {Module/Scope}

### Compliance Summary
- Level A Violations: X
- Level AA Violations: X
- Best Practice Issues: X
- WCAG Categories Affected: {list}

### Findings

#### [AA VIOLATION] SC 1.1.1 — Missing alt text on product images
**File**: `path/to/template.phtml:42`
**Impact**: Screen reader users cannot perceive image content
**Current**: `<img src="<?= $imageUrl ?>">`
**Remediation**:
`<img src="<?= $escaper->escapeUrl($imageUrl) ?>" alt="<?= $escaper->escapeHtmlAttr($productName) ?>">`

#### [A VIOLATION] SC 2.1.1 — Non-keyboard-accessible custom dropdown
**File**: `path/to/widget.js:87`
**Impact**: Keyboard-only users cannot interact with the dropdown
**Remediation**: Add `keydown` handler for Enter/Space/Escape and arrow key navigation

### Recommendations
- {Prioritized list of fixes — violations first, then best practices}
```

## References
- [WCAG 2.1 Specification](https://www.w3.org/TR/WCAG21/)
- [WCAG 2.1 Quick Reference (How to Meet)](https://www.w3.org/WAI/WCAG21/quickref/?versions=2.1&levels=aaa)
- [WAI-ARIA Authoring Practices 1.2](https://www.w3.org/TR/wai-aria-practices-1.2/)
- [Adobe Commerce Accessibility](https://developer.adobe.com/commerce/frontend-core/guide/accessibility/)
- [ARIA in HTML](https://www.w3.org/TR/html-aria/)
- [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)
