---
name: code-review
description: "Comprehensive PHP code review for Magento 2 modules. Use when reviewing pull requests, auditing module quality, or checking code before merge. Covers coding standards, architecture, security, performance, and Magento best practices."
argument-hint: "Path to module or file(s) to review"
---

# Magento 2 PHP Code Review

## When to Use
- Reviewing a pull request or set of changes
- Auditing a module for quality before release
- Checking code before merge to main branch
- General code quality assessment

## Required Instructions

Before reviewing, load the instruction files relevant to the file types actually present in the module — do not load all of them upfront. Match file types to instruction files:

| Instruction file | Load when |
|---|---|
| `instructions/security-php.instructions.md` | PHP files are present |
| `instructions/magento-php.instructions.md` | PHP files are present |
| `instructions/phtml-templates.instructions.md` | PHTML files are present |
| `instructions/magento-xml.instructions.md` | XML config files are present |
| `instructions/javascript-frontend.instructions.md` | JS files are present |

Load each applicable instruction file **in the same turn as the first batch of that file type** — not before reading any code files. This avoids loading rules for file types that don't exist in the module.

## Review Checklist

### 1. Coding Standards (PSR-12 + Magento)
- [ ] `declare(strict_types=1);` present
- [ ] Return type declarations on all methods
- [ ] Typed properties used (PHP 8.x)
- [ ] Proper namespace pattern: `Mage\{ModuleName}\{SubNamespace}`
- [ ] No unused imports or variables
- [ ] Method complexity reasonable (< 20 lines preferred)

### 2. Convention & Structure
- [ ] Class functionality limited to a single responsibility
- [ ] Directory structure follows Magento conventions (Api/, Block/, Controller/, Model/, Plugin/, ViewModel/, etc.)
- [ ] Functionality performed at the correct level (server, client, CSS, JS, database, framework)
- [ ] Module, package, and repository naming conventions correct
- [ ] Versioning correct
- [ ] Global CSS styles applied thoughtfully and not overused
- [ ] Code does not look unconventional or work around a problem the wrong way

### 3. Dependency Injection
- [ ] Constructor injection only — no `ObjectManager::getInstance()`
- [ ] Type-hint interfaces, not concrete classes
- [ ] Preferences and arguments configured in `etc/di.xml`
- [ ] No service locator anti-pattern

### 4. Plugin Quality
- [ ] Plugins used instead of class rewrites where possible
- [ ] `before`/`after` preferred over `around` — `around` plugins are a review flag
- [ ] Plugin does not modify `__construct` or `__destruct`
- [ ] `sortOrder` set appropriately in `di.xml`
- [ ] Plugin class is in `Plugin/` directory
- [ ] Plugins return the correct types of data

### 5. Completeness
- [ ] Code can be enabled/disabled by configuration and all code respects the flag
- [ ] All configuration present: check scope, data type, validation, translation, and default values
- [ ] Configuration retrieved at the lowest possible level matching `system.xml` scope definition
- [ ] ACLs defined for new functionality
- [ ] PhpDocs clear, commit messages clear
- [ ] No commented-out code or debug code (`var_dump`, `print_r`, `debug_backtrace`)

### 6. Performance
- [ ] No full collection loads — `addFieldToFilter()` and `setPageSize()` used
- [ ] No model loading inside loops
- [ ] No queries executed in loops (check parent callers too)
- [ ] Database queries optimized (joins vs multiple queries)
- [ ] Cache usage where appropriate (`\Magento\Framework\App\CacheInterface`)
- [ ] No unnecessary event observers on high-frequency events
- [ ] `cacheable="false"` used correctly — **never** on catalog/product/CMS pages (disables FPC for entire page)

### 8. Architecture
- [ ] Repository pattern for data access
- [ ] Data Interfaces for DTOs
- [ ] ViewModels for frontend logic (not Block classes)
- [ ] Service Contracts define module API
- [ ] Proper module dependencies in `module.xml` `<sequence>`
- [ ] No circular dependencies

### 9. Error Handling
- [ ] Specific exception types thrown (not generic `\Exception`)
- [ ] Exceptions logged with appropriate level
- [ ] No silent `catch` blocks
- [ ] User-facing messages use `__()` translation

### 10. Configuration
- [ ] `di.xml` schema URN present
- [ ] System config fields have proper validation
- [ ] Default values set in `config.xml`
- [ ] Sensitive config marked as `<backend_model>Magento\Config\Model\Config\Backend\Encrypted</backend_model>`

## Automation Commands

Run all available checks in a **single chained terminal command**:

```bash
cd <project-root> && \
  echo '=== PHPCS ===' && \
  vendor/bin/phpcs --standard=Magento2 <module-path> 2>&1 | tail -50 && \
  echo '=== PHPSTAN ===' && \
  vendor/bin/phpstan analyse <module-path> --level=5 2>&1 | tail -50 && \
  echo '=== DI COMPILE ===' && \
  bin/magento setup:di:compile -vv 2>&1 | tail -20
```

Do not run these as separate `run_in_terminal` calls — **one `run_in_terminal` call for the entire validation phase**. Pipe or redirect output and use `tail` to prevent terminal output from flooding the context.

## Procedure
1. Identify the scope: module path, changed files, or PR diff.
2. Read all target files in batches of **4–6 files per turn** using multiple `read_file` calls in a single output, grouped by type (all PHP first, then all XML, then all PHTML/JS). **Never call `read_file` once per turn** — always read the next 4–6 files together. Load the relevant instruction files in the same turn as the first batch of each file type — not before.
3. After each batch, write a `## Findings: <area>` block (max 150 tokens) noting violations and observations. This block replaces the raw file content for all subsequent reasoning — do not reference raw content again.
4. After all files are read and all `## Findings` blocks are written, run the automation commands in a single terminal call.
5. Evaluate all findings against the checklist above.
6. For each finding, provide:
   - **Severity**: Critical / Major / Minor / Suggestion
   - **Location**: File and line number
   - **Issue**: What's wrong
   - **Fix**: Concrete suggestion
7. Summarize: total findings by severity, overall quality assessment.
8. Highlight any blocking issues that must be fixed before merge.

## Output Format
```
## Code Review: {Module/Scope}

### Summary
- Critical: X | Major: X | Minor: X | Suggestions: X
- Overall: {PASS / NEEDS WORK / FAIL}

### Findings

#### [CRITICAL] {Title}
**File**: `path/to/file.php:42`
**Issue**: Description
**Fix**: Concrete code suggestion

#### [MAJOR] {Title}
...
```

## References
- [Adobe Code Review Best Practices](https://experienceleague.adobe.com/en/docs/commerce-operations/implementation-playbook/best-practices/development/code-review)