---
name: elasticsearch
description: "Elasticsearch expertise for Magento 2 — index mapping, query optimization, custom search attributes, relevance tuning, debugging search/filter issues, and catalog search performance."
argument-hint: "Describe the Elasticsearch issue or what you want to optimize"
---

# Magento 2 Elasticsearch Expert

## When to Use
- Debugging search or catalog filter issues
- Optimizing search relevance or performance
- Adding custom searchable/filterable attributes
- Reviewing index mappings
- Troubleshooting reindex failures
- Configuring analyzers or tokenizers

## Magento 2 + Elasticsearch Architecture

### Key Components
- **Indexer**: `catalogsearch_fulltext` — rebuilds ES index from catalog data
- **Adapter**: `\Magento\Elasticsearch\Model\Adapter\Elasticsearch` — communicates with ES
- **Field Mapper**: Maps Magento attributes to ES field types
- **Query Builder**: Converts SearchCriteria to ES queries
- **Config**: `Stores > Configuration > Catalog > Catalog Search`

### Index Structure
- Index per store view: `magento2_{store_code}_catalogsearch_fulltext`
- Each document = one product with all searchable/filterable attributes
- Mapping types: `keyword` (exact), `text` (analyzed), `integer`, `float`, `date`

## Common Tasks

### Adding a Custom Searchable Attribute
1. Create attribute via `InstallData`/`UpgradeData` or `db_schema.xml` + data patch
2. Set attribute properties:
   - `is_searchable = 1` for full-text search
   - `is_filterable = 1` for layered navigation
   - `is_filterable_in_search = 1` for search results filtering
   - `search_weight` = 1-10 (higher = more relevance)
3. Reindex: `bin/magento indexer:reindex catalogsearch_fulltext`
4. Verify mapping: `GET /{index}/_mapping`

### Debugging Search Issues
1. **Check index exists**: `GET /_cat/indices?v&index=magento2_*`
2. **Check mapping**: `GET /{index}/_mapping` — verify field types
3. **Test query directly**: Use `GET /{index}/_search` with the query body
4. **Analyze text**: `GET /{index}/_analyze` with analyzer and sample text
5. **Check Magento logs**: `var/log/elasticsearch.log` (if enabled)
6. **Check indexer status**: `bin/magento indexer:status catalogsearch_fulltext`

### Query Optimization
- Use `bool` query with `must`/`should`/`filter` correctly:
  - `filter` for exact matches (cached, no scoring)
  - `must` for required conditions with scoring
  - `should` for boosting optional matches
- Avoid `wildcard` queries on large fields — use `match` or `match_phrase`
- Use `keyword` subfield for sorting and aggregations
- Limit `_source` fields to only what's needed for results

### Relevance Tuning
- `search_weight` on attributes (1-10) maps to field boost
- Custom boosting via plugin on `\Magento\Elasticsearch\Model\Adapter\BatchDataMapper\ProductDataMapper`
- Use `function_score` for business rules (boost new products, popular items)
- Multi-match queries: `best_fields` vs `cross_fields` vs `most_fields`

### Performance
- Use `filter` context for non-scoring conditions (enables caching)
- Limit aggregations: only include filterable attributes
- Pagination: avoid deep pagination (`from` > 10000) — use `search_after`
- Bulk operations for reindex — Magento does this by default
- Monitor slow queries: `PUT /{index}/_settings { "index.search.slowlog.threshold.query.warn": "2s" }`

## Environment-Specific Notes
- Each environment may have its own Elasticsearch index
- Multi-language considerations: ensure analyzers match the language of each store view

## Troubleshooting Checklist
- [ ] ES service running and reachable from Magento
- [ ] Index exists and has documents: `GET /{index}/_count`
- [ ] Mapping correct for the attribute in question
- [ ] Attribute marked searchable/filterable in admin
- [ ] Reindex completed successfully after attribute changes
- [ ] Store view matches index (multi-store setup)
- [ ] Analyzer appropriate for the language/use case
