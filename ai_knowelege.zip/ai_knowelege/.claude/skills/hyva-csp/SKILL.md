---
name: hyva-csp
description: "CSP compliance check and auto-fix for Hyvä PHTML templates. Extracts inline Alpine.js expressions to named methods, adds HyvaCsp boilerplate, removes inline event attributes."
argument-hint: "Path to PHTML file(s) to check"
---

# Hyvä CSP Compliance — Auto-Fix

## When to Use
- Before committing any `.phtml` file with Alpine.js / inline `<script>`
- After adding new Alpine directives to an existing template
- When CSP errors appear in browser console for inline scripts

## Process

### Step 1 — Read the file
Use `read_file` on the target `.phtml`.

### Step 2 — Check boilerplate

| Check | Fix if missing |
|-------|---------------|
| `use Hyva\Theme\ViewModel\HyvaCsp;` | Add in strict alphabetical order among `use` statements |
| `/** @var HyvaCsp $hyvaCsp */` | Add after last `@var` line |
| `<?php isset($hyvaCsp) && $hyvaCsp->registerInlineScript() ?>` | Add as very last line of file |

**Alphabetical order rule** (phpcs Mage: `SlevomatCodingStandard.Namespaces.AlphabeticallySortedUses`):
`Hyva\CmsLiveviewEditor\...` < `Hyva\Theme\ViewModel\HyvaCsp` < `Hyva\Theme\ViewModel\Media` < `Lippert\...` < `Magento\...`

### Step 3 — Fix Alpine anti-patterns

#### A. Inline arguments → wrapper method

| Before (HTML) | After (HTML) | JS |
|---|---|---|
| `@click="handler($event)"` | `@click="handler"` | reads `this.$event` |
| `@click="handler(item.id)"` | `@click="handlerFromClick"` | `const id = this.item.id;` |
| `x-data="initFoo($el)"` | `x-data="initFoo"` | `const el = this.$el;` in `init()` |
| `:class="fn($store.foo)"` | `:class="fn"` | `const foo = this.$store.foo;` |
| `x-show="fn($refs.el)"` | `x-show="fn"` | `const el = this.$refs.el;` |

#### B. Dot-access expressions → `get`-prefixed method

Extract ALL `x-text`, `x-html`, `x-show`, `x-if`, `:attr` with dot-access to named methods.
Prefix with `get` + PascalCase path.

```
x-html="cart.subtotal"              → x-html="getCartSubtotal"
                                       getCartSubtotal() { return this.cart.subtotal; }

x-text="item.product_name"          → x-text="getItemProductName"
                                       getItemProductName() { return this.item.product_name; }

:href="item.product_url"             → :href="getItemProductUrl"
                                       getItemProductUrl() { return this.item.product_url; }

x-for="(x, i) in item.options"      → x-for="(x, i) in getItemOptions"
                                       getItemOptions() { return this.item.options; }

x-if="option.status === PHP_CONST"  → x-if="isOptionOutOfStock"
                                       isOptionOutOfStock() { return this.option.status === PHP_CONST; }
```

**Skip:** `x-model` (two-way binding), `x-for="(x) in …"` iteration syntax itself, `:key`.

**x-for scope in `<script>` body:** loop variables (`item`, `option`) become `this.item`, `this.option`.

**Nested `x-data` components** (e.g. `bundleToggler`): define their own getter methods for their own loop variables; parent-scope getters (e.g. `getItemOptions`) are accessible via Alpine scope chain.

#### C. Remove inline HTML event attributes
`onclick="..."` / `onchange="..."` → move logic to Alpine `@click` / `@change` + named method in `<script>`.

#### D. Escaping check
Every `<?= $var ?>` must use `$escaper->escapeHtml|escapeHtmlAttr|escapeUrl|escapeJs|escapeCss`
or have `/* @noEscape */` comment. Flag any violations.

### Step 4 — Apply fixes

Use targeted edits — do not rewrite unchanged code:

| Operation | VS Code tool | Claude Code tool |
|---|---|---|
| Add new line (`use`, `@var`, `registerInlineScript()`) | `insert_edit_into_file` | `Edit` (empty `old_string` at insertion point) |
| Replace existing content (HTML attributes, JS expressions) | `replace_string_in_file` | `Edit` |

### Step 5 — Report

```
✅ use HyvaCsp — already present
✅ @var HyvaCsp — already present
✅ registerInlineScript() — already present
🔧 FIXED  [line N] before → after (+ JS change)
⚠️  MANUAL [line N] reason auto-fix not possible
```

Boilerplate items added by the skill in Step 2 are reported as `🔧 FIXED`, not `✅`. Only items that were already present before the skill ran use `✅`.

