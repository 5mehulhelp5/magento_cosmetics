# local-database-access rules

This file is the source of truth for operational and safety rules used by the `local-database-access` skill.

## Access Rules

### Safe operations (no confirmation required)

- `SELECT`
- `SHOW`
- `DESCRIBE`
- `EXPLAIN`

### Operations requiring explicit user confirmation

- `DELETE`, `TRUNCATE`, `DROP`
- `ALTER TABLE`, `CREATE TABLE`, `DROP TABLE`
- `UPDATE`, `INSERT`, `REPLACE`
- Any bulk or potentially destructive operation

If there is any ambiguity, treat the query as unsafe and ask first.

## Procedure

1. Classify the requested SQL as safe or unsafe.
2. If safe, execute and return results clearly.
3. If unsafe, show the exact statement and ask for explicit approval before execution.
4. For schema exploration, prefer `SHOW CREATE TABLE`, `DESCRIBE`, and targeted `SELECT` queries.
5. Summarize results with enough context for decision-making.

## Output Rules

- Include the executed query.
- Include a concise result summary (counts, key rows, or schema highlights).
- Include caveats when relevant (empty results, missing tables, environment mismatch).
