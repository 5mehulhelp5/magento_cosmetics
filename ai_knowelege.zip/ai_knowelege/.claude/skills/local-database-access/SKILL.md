---
name: local-database-access
description: "Query and inspect the local Magento database using Warden with strict safety gates. Use when the user asks to run SQL, inspect schema, validate records, or verify data assumptions — and proactively during bug investigation whenever confirming actual DB state (data, schema, config) would help diagnose the issue, not just when explicitly asked to query. Safe read-only SQL runs immediately; destructive/write SQL requires explicit confirmation first."
metadata:
  category: "database"
  project: "Cosmetics (Mage)"
  scope: "Local Development"
---

# local-database-access

Safely access the local Magento MariaDB database from this repository.

## Available Databases (Warden · MariaDB 10.11)

All connections go through `warden db connect`, which reads credentials from `app/etc/env.php` and connects as `root`.

| Context | Database | User | Password |
|---|---|---|---|
| Local development (default) | `uat` | `root` | `magento` |

## When to use

Trigger this skill when the user asks to:

- Run SQL queries for investigation or validation
- Inspect schema, tables, columns, indexes, or row counts
- Verify product, customer, order, voucher, or configuration data
- Debug data issues

Also trigger it proactively — without being asked — whenever you (the AI) need database information to make progress on a bug investigation. If a hypothesis about the bug's cause can be confirmed or ruled out by looking at actual data or schema (e.g. "does this order really have this status", "is this attribute actually set on the product", "does this config value exist in `core_config_data`"), query the database directly instead of asking the user to check or guessing from code alone. Safe read-only queries (see Rules) do not require asking first.

Do not use this skill for wiki updates or documentation refresh tasks.

## Rules

All safety and execution rules are defined in [RULES.md](RULES.md).

## Connection Commands

```bash
# Open interactive DB shell (default database: uat)
warden db connect

# Execute a direct query
warden db connect -e "SELECT COUNT(*) FROM catalog_product_entity;"

# Inspect table definition
warden db connect -e "SHOW CREATE TABLE sales_order\\G"
```
