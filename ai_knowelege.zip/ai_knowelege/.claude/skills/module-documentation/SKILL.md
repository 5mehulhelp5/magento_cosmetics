---
name: module-documentation
description: "Generate or update module documentation. Use when creating a new Magento 2 module README.md, documenting an existing module, updating the central module registry in docs/modules/README.md, or writing ADRs. Covers functional specs, technical docs, sequence diagrams, API definitions, database changes."
argument-hint: "Module path or name to document, e.g. app/module-mage-checkout"
---

# Magento 2 Module Documentation

## When to Use
- Creating a new module — generate its README.md
- Documenting an existing module that lacks documentation
- Updating documentation after significant changes
- Adding the module to the central registry (`docs/modules/README.md`)
- Writing an Architecture Decision Record (ADR)

## Procedure

### Step 1: Gather Module Context

**In a single exploration pass**, read all of the following that exist — do not request files individually:

- `composer.json` — name, description, version, authors, dependencies
- `etc/module.xml` — module name and sequence dependencies
- `etc/di.xml`, `etc/frontend/di.xml`, `etc/adminhtml/di.xml` — plugins and preferences
- `etc/webapi.xml` — REST/GraphQL API endpoints
- `etc/db_schema.xml` and `Setup/` — database changes
- `etc/events.xml`, `etc/crontab.xml` — observers and cron jobs
- All files under `Controller/` and `Api/` — entry points
- `etc/adminhtml/system.xml` — configuration fields

### Step 2: Generate Module README.md
Create `app/{module-name}/README.md` using the template in [Module README Template](#module-readme-template).

Fill in all applicable sections. Remove sections that don't apply (e.g., no API section if no `webapi.xml`).

### Step 3: Update Central Registry
Update `docs/modules/README.md` — add or update the module row in the registry table. See [Registry Template](#central-registry-template).

### Step 4: ADR (if applicable)
If the module introduces a significant architectural decision, create an ADR file at `docs/architecture/ADR-{NNN}-{title}.md`. See [ADR Template](#adr-template).

---

## Module README Template

```markdown
# {Vendor}_{ModuleName}

> {One-line description from composer.json}

## Overview

{2-3 sentences explaining what this module does, which business problem it solves, and which environments use it.}

**Environments**: {All | cz, ee | it, meb | etc.}
**Version**: {from composer.json}
**Author**: {from composer.json authors or git log}

## Features

- {Feature 1}
- {Feature 2}
- {Feature 3}

## Architecture

### Dependencies

| Module | Purpose |
|--------|---------|
| `{dependency}` | {why it's needed} |

### Key Components

| Component | Type | Description |
|-----------|------|-------------|
| `{ClassName}` | Plugin / Observer / Model / etc. | {what it does} |

### Sequence Diagram

{Include when the module has non-trivial flows — API calls, ERP integration, multi-step processes}

` ` `mermaid
sequenceDiagram
    participant C as Customer
    participant M as Magento
    participant E as External Service
    C->>M: {action}
    M->>E: {request}
    E-->>M: {response}
    M-->>C: {result}
` ` `

## Configuration

{Include when etc/adminhtml/system.xml exists}

| Path | Type | Default | Description |
|------|------|---------|-------------|
| `{section/group/field}` | {text/select/multiselect} | `{default}` | {what it controls} |

## API

{Include when etc/webapi.xml exists}

### REST Endpoints

| Method | URL | ACL | Description |
|--------|-----|-----|-------------|
| `GET` | `/V1/{resource}` | `{acl_resource}` | {description} |
| `POST` | `/V1/{resource}` | `{acl_resource}` | {description} |

### Request/Response Examples

` ` `json
// GET /V1/{resource}/{id}
{
    "field": "value"
}
` ` `

## Database

{Include when etc/db_schema.xml or Setup/ migrations exist}

### Tables

| Table | Description |
|-------|-------------|
| `{table_name}` | {purpose} |

### Schema Changes

| Column | Type | Table | Description |
|--------|------|-------|-------------|
| `{column}` | `{varchar(255)}` | `{table}` | {purpose} |

## Events & Observers

{Include when etc/events.xml exists}

| Event | Observer | Description |
|-------|----------|-------------|
| `{event_name}` | `{ObserverClass}` | {what it does} |

## Cron Jobs

{Include when etc/crontab.xml exists}

| Job | Schedule | Description |
|-----|----------|-------------|
| `{job_name}` | `{cron_expression}` | {what it does} |

## Testing

{How to test this module — manual steps, automated tests, key scenarios}

## Changelog

See [CHANGELOG.md](CHANGELOG.md) if available, or check git history.
```

**Important**: Remove any section that does not apply. Do not leave empty sections.

---

## Central Registry Template

The file `docs/modules/README.md` must maintain a complete table of all documented modules:

```markdown
# Module Registry

> Central index of all custom modules. Keep this file updated when adding or modifying modules.

Last updated: {YYYY-MM-DD}

## Modules

| Module | Version | Last Updated | Description | Author | Environments |
|--------|---------|-------------|-------------|--------|-------------|
| [module-mage-core](../../app/module-mage-core/README.md) | 1.0.0 | YYYY-MM-DD | Core shared module | Team | All |
| [module-mage-catalog](../../app/module-mage-catalog/README.md) | x.y.z | YYYY-MM-DD | Catalog customizations | Team | All |
```

**Rules for the registry:**
- Sort alphabetically by module name
- Link to the module's README.md using relative path `../../app/{name}/README.md`
- Version from `composer.json` (or `@dev` if path dependency)
- Last Updated = date of last significant change (from git log or current date)
- Description = one line from `composer.json` description field
- Author = from `composer.json` authors or team name as default
- Environments = which environments use this module (All, or comma-separated codes)

---

## ADR Template

Architecture Decision Records go in `docs/architecture/ADR-{NNN}-{kebab-case-title}.md`:

```markdown
# ADR-{NNN}: {Title}

**Date**: {YYYY-MM-DD}
**Status**: {Proposed | Accepted | Deprecated | Superseded by ADR-XXX}
**Author**: {name}

## Context

{What is the issue that we're seeing that motivates this decision?}

## Decision

{What is the change that we're proposing and/or doing?}

## Consequences

### Positive
- {benefit 1}
- {benefit 2}

### Negative
- {tradeoff 1}
- {tradeoff 2}

### Affected Modules
- `{module-name}` — {how it's affected}

### Affected Environments
- {All | specific environment codes}
```

**ADR numbering**: Check existing files in `docs/architecture/` and use the next sequential number, padded to 3 digits (001, 002, ...).
