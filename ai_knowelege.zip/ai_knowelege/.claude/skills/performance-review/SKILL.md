---
name: performance-review
description: "Performance review and optimization for Magento 2 modules. Use when diagnosing slow pages, optimizing database queries, reviewing N+1 problems, caching strategy, indexer performance, or frontend loading."
argument-hint: "Path to module, page, or describe the performance issue"
---

# Magento 2 Performance Review

## When to Use
- Diagnosing slow page loads or API responses
- Reviewing a module for performance anti-patterns
- Optimizing database queries or collection usage
- Evaluating caching strategy
- Frontend performance (JS/CSS loading)

## Review Procedure

> **Efficiency**: Gather all target files in a single exploration pass before analysing — do not read files one at a time in a loop.

### 1. PHP / Backend Performance

**Collection & Query Anti-patterns:**
- [ ] No `load()` on full collections without filters — always `addFieldToFilter()` + `setPageSize()`
- [ ] No model `load()` inside loops — batch with `SearchCriteria` and `getList()`
- [ ] No `count()` on collections when only checking emptiness — use `getSize()` or `count()` on already-loaded
- [ ] No `getData()` on full collections to convert to arrays — use `toArray()` or iterate
- [ ] Joins used instead of multiple sequential queries where appropriate
- [ ] Indexes exist on frequently filtered/sorted columns

**N+1 Query Detection:**
1. Look for loops that load related entities one-by-one
2. Check if parent collection could use `joinTable()` or eager loading
3. Suggest batch loading with `getList()` + `SearchCriteria` with `addFieldToFilter('entity_id', ['in' => $ids])`

**Caching:**
Per the [Adobe caching guide](https://developer.adobe.com/commerce/frontend-core/guide/caching):
- [ ] Expensive computations cached via `\\Magento\\Framework\\App\\CacheInterface`
- [ ] Cache tags set correctly for invalidation
- [ ] Full-page cache (FPC) compatibility — no private data in cacheable blocks
- [ ] Block cacheable attribute set correctly in layout XML: `cacheable=\"false\"` only when truly necessary
- [ ] **CRITICAL**: `cacheable=\"false\"` on any block disables FPC for the **entire page** — never use on content pages (catalog, product, CMS)
- [ ] Private content (per-user data) handled client-side via `customerData` sections, not by disabling cache
- [ ] Public content (shared across users) properly cached in reverse proxy (Varnish recommended)
- [ ] Only HTTP GET and HEAD requests are cached — POST/PUT/DELETE bypass cache
- [ ] HTTP cache headers appropriate for API responses
- [ ] Varnish or built-in FPC configured per Adobe recommendations

**Indexers:**
- [ ] Custom indexers use `\Magento\Framework\Mview` (materialized views) where beneficial
- [ ] Indexer `executeFull()` handles large datasets with batching
- [ ] Changelog (mview) preferred over full reindex triggers
- [ ] No reindex triggers on every save — use scheduled mode

### 2. Frontend Performance

**JavaScript:**
- [ ] JS modules lazy-loaded (not in `deps` unless truly global)
- [ ] No synchronous AJAX (`async: false`)
- [ ] `domReady!` used instead of `$(document).ready()`
- [ ] Heavy components deferred below the fold
- [ ] No inline `<script>` — use RequireJS

**CSS/LESS:**
- [ ] No `@import` of entire framework files — extend specific variables
- [ ] Critical CSS considered for above-the-fold content (use [CSS critical path](https://developer.adobe.com/commerce/frontend-core/guide/css/critical-path/))
- [ ] LESS compilation produces minimal output — no duplicated rules
- [ ] Style custom modules inside the module's `view/frontend/web/css/source/`, not in the theme — styles only load when the module is active
- [ ] Separate LESS files per component instead of one monolithic stylesheet

**Layout XML:**
- [ ] Unnecessary blocks removed for pages that don't need them
- [ ] `cacheable=\"false\"` only on blocks that truly need it (it disables FPC for the entire page!)
- [ ] Never set content pages (catalog, product, CMS) as uncacheable — severe performance impact
- [ ] `ifconfig` used to conditionally render blocks based on config

### 3. Elasticsearch Performance

- [ ] Custom search attributes have appropriate `is_searchable`, `is_filterable` settings
- [ ] No overly broad wildcard queries
- [ ] Aggregations limited to necessary attributes
- [ ] Index mappings reviewed for field type appropriateness

## Output Format
```
## Performance Review: {Module/Scope}

### Summary
- Critical Issues: X (blocking for production)
- Optimization Opportunities: X
- Estimated Impact: {High/Medium/Low}

### Findings

#### [CRITICAL] N+1 Query in {ClassName}
**File**: `path/to/file.php:42`
**Impact**: ~{N} extra DB queries per request
**Current**: {code pattern causing the issue}
**Recommended**: {batch loading approach}

### Quick Wins
- {List of easy optimizations with high impact}

### Long-term Recommendations
- {Architectural improvements}
```
