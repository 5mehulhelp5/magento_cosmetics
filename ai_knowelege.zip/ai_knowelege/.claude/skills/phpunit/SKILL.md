---
name: phpunit
description: "Generate or improve PHPUnit tests for Magento 2 modules. Use when writing unit tests, creating test classes, mocking Magento dependencies, or increasing test coverage. Covers Magento test conventions and common testing patterns."
argument-hint: "Class or module path to generate tests for, e.g. app/module-mage-checkout/src/Model/Payment.php"
---

# Magento 2 PHPUnit Testing

## When to Use
- Writing unit tests for a new or existing class
- Generating test stubs for a module with empty `Test/` or `test/` directories
- Improving test coverage for an existing module
- Mocking Magento framework dependencies (repositories, collections, requests)
- Debugging a failing test

## Test Infrastructure

### Testing Framework
- **Base**: PHPUnit 10.x (or whatever version your project uses)
- **Optional helpers**: Testing tools packages that provide `real()`, `mock()`, `get()`, `deep()` helpers
- **Reporting**: `allure-framework/allure-phpunit` for test reports (optional)

### Directory Conventions

All tests live under `src/Test/Unit/`, mirroring the source namespace structure.

Example: `module-mage-checkout/src/Test/Unit/Model/PaymentTest.php`

### Base Test Class

All unit tests should extend the module's `AbstractTestCase` or `\PHPUnit\Framework\TestCase`:

```php
<?php

declare(strict_types=1);

namespace {Vendor}\{ModuleName}\Test\Unit;

class AbstractTestCase extends \PHPUnit\Framework\TestCase
{
}
```

## Procedure

> **Efficiency**: When a module path is given (rather than a single class), list all PHP classes in the module in a single pass first, then read all of them together before generating tests — do not read and generate one class at a time.

### Step 1: Analyze the Target Class
1. Read the class under test — identify public methods, constructor dependencies, return types
2. Identify which dependencies need mocking (interfaces, repositories, collections, etc.)
3. Note any Magento framework interactions (events, cache, session, request)

### Step 2: Create Test Structure
1. Mirror the source namespace under `Test/Unit/`:
   - Source: `{Vendor}\MageCatalog\Model\Product\Validator`
   - Test: `{Vendor}\MageCatalog\Test\Unit\Model\Product\ValidatorTest`
2. Create or extend `AbstractTestCase` if the module has one
3. Name the test file `{ClassName}Test.php`

### Step 3: Write Tests

Follow this template for each test class:

```php
<?php

declare(strict_types=1);

namespace {Vendor}\{ModuleName}\Test\Unit\{SubNamespace};

use PHPUnit\Framework\MockObject\MockObject;
use {Vendor}\{ModuleName}\{SubNamespace}\{ClassName};

class {ClassName}Test extends \PHPUnit\Framework\TestCase
{
    /** @var {ClassName} */
    private {ClassName} $subject;

    /** @var {DependencyInterface}&MockObject */
    private {DependencyInterface} $dependencyMock;

    protected function setUp(): void
    {
        $this->dependencyMock = $this->createMock({DependencyInterface}::class);

        $this->subject = new {ClassName}(
            $this->dependencyMock
        );
    }

    public function testMethodReturnsExpectedResult(): void
    {
        // Arrange
        $this->dependencyMock
            ->expects($this->once())
            ->method('getData')
            ->willReturn(['key' => 'value']);

        // Act
        $result = $this->subject->process();

        // Assert
        $this->assertEquals('expected', $result);
    }

    public function testMethodThrowsOnInvalidInput(): void
    {
        $this->expectException(\Magento\Framework\Exception\LocalizedException::class);

        $this->subject->process(null);
    }
}
```

### Step 4: Test Naming Conventions
- Test method names: `test{MethodName}{Scenario}{ExpectedBehavior}`
  - `testGetPricesReturnsEmptyArrayWhenNoProducts`
  - `testCreateOrderThrowsExceptionOnInvalidCustomer`
  - `testValidateReturnsTrueForValidInput`
- Use `@dataProvider` for testing multiple input/output combinations
- Use `@covers` annotation to map tests to source methods

## Mocking Magento Dependencies

### Common Patterns

**Repository mock:**
```php
$this->productRepository = $this->createMock(\Magento\Catalog\Api\ProductRepositoryInterface::class);
$this->productRepository
    ->method('getById')
    ->willReturn($this->createConfiguredMock(\Magento\Catalog\Api\Data\ProductInterface::class, [
        'getSku' => 'TEST-SKU',
        'getName' => 'Test Product',
    ]));
```

**SearchCriteria + SearchResults mock:**
```php
$searchCriteria = $this->createMock(\Magento\Framework\Api\SearchCriteriaInterface::class);
$this->searchCriteriaBuilder
    ->method('addFilter')
    ->willReturnSelf();
$this->searchCriteriaBuilder
    ->method('create')
    ->willReturn($searchCriteria);

$searchResults = $this->createMock(\Magento\Framework\Api\SearchResultsInterface::class);
$searchResults->method('getItems')->willReturn([$itemMock]);
$this->repository->method('getList')->willReturn($searchResults);
```

**Request mock:**
```php
$this->request = $this->createMock(\Magento\Framework\App\RequestInterface::class);
$this->request->method('getParam')->willReturnMap([
    ['id', null, '42'],
    ['store', null, '1'],
]);
```

**Collection mock:**
```php
$collection = $this->createMock(\Magento\Catalog\Model\ResourceModel\Product\Collection::class);
$collection->method('addFieldToFilter')->willReturnSelf();
$collection->method('setPageSize')->willReturnSelf();
$collection->method('getItems')->willReturn([$productMock]);
```

**Logger (just verify it's called):**
```php
$this->logger = $this->createMock(\Psr\Log\LoggerInterface::class);
$this->logger->expects($this->once())->method('error');
```

### Testing Tools Helpers

If the module uses a testing tools package (e.g., custom `AbstractTestCase`), these helpers may be available:

| Helper | Purpose |
|--------|---------|
| `$this->real(ClassName::class)` | Create real instance with auto-resolved deps |
| `$this->mock(ClassName::class)` | Create PHPUnit mock |
| `$this->get(ClassName::class)` | Get from test object manager |
| `$this->deep()` | Deep mock chain for nested calls |

## Test Quality Checklist

- [ ] **One assertion focus per test** — test one behavior, not many
- [ ] **Arrange-Act-Assert** structure in every test
- [ ] **No logic in tests** — no if/else, loops, or try/catch in test methods
- [ ] **Mocks set expectations** — use `expects($this->once())` not just `method()`
- [ ] **Edge cases covered** — null input, empty collections, exceptions
- [ ] **No Magento bootstrap** — unit tests must run without Magento (no `ObjectManager`)
- [ ] **Fast execution** — each test under 100ms, no I/O, no DB
- [ ] **Descriptive names** — test name describes scenario and expected behavior

## Output Format

When generating tests, provide:
1. The complete test class file with all test methods
2. An `AbstractTestCase` if the module doesn't have one
3. Suggested additional test cases as a checklist
4. Any missing constructor dependencies that need mocking
