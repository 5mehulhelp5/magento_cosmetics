---
name: security-audit
description: "OWASP-focused security audit for Magento 2 modules. Use when checking for vulnerabilities, preparing for security review, or auditing a module for injection, XSS, CSRF, access control, and other OWASP Top 10 issues."
argument-hint: "Path to module or file(s) to audit"
---

# Magento 2 Security Audit (OWASP Top 10)

## When to Use
- Security audit before release or deployment
- Reviewing code for known vulnerability patterns
- Preparing for penetration testing
- After a security incident to find similar patterns

## Audit Procedure

> **Efficiency**: Gather all target files in a single exploration pass before analysing — do not read files one at a time in a loop. Read all PHP, PHTML, and JS files together, then analyse.

### Phase 1: Automated Pattern Scan
Search the target code for dangerous patterns. For each category, search for the listed patterns and flag any matches:

**A03 — Injection**
Search patterns:
- `$connection->query(` without bind params
- `->where("` with variable concatenation (not `->where('field = ?', $value)`)
- `shell_exec(`, `exec(`, `system(`, `passthru(`, `proc_open(`, backtick operator
- `eval(`, `assert(`, `create_function(`, `preg_replace` with `/e`
- `$_GET`, `$_POST`, `$_REQUEST`, `$_SERVER` (direct superglobal access)

**A07 — XSS**
Search patterns:
- `echo $` in `.phtml` files without `$escaper->` wrapper
- `<?= $` without `$escaper->escapeHtml`
- `.html(` in JS with variable argument
- `innerHTML =` in JS
- `__($variable)` used as escaping (it's NOT escaping)

**A01 — Broken Access Control**
Search patterns:
- Admin controllers without `ADMIN_RESOURCE` constant
- Frontend controllers returning data without customer session validation
- API resources without `<resource>` ACL in `webapi.xml`
- Missing `isAllowed()` checks

**A02 — Cryptographic Failures**
Search patterns:
- `md5(`, `sha1(` used for security (hashing passwords, tokens)
- Hardcoded strings that look like API keys, tokens, passwords
- `base64_encode` used as "encryption"
- Plain-text storage of sensitive data

**A08 — Insecure Deserialization**
Search patterns:
- `unserialize(` (use `Json::unserialize()` instead)
- `\Magento\Framework\Serialize\Serializer\Serialize` (legacy, use `Json`)

**A10 — SSRF**
Search patterns:
- `file_get_contents(` with variable URL
- `curl_init(` with user-controlled URL
- HTTP client calls where URL comes from user input or database without validation

**A05 — Security Misconfiguration**
Search patterns:
- `var_dump(`, `print_r(`, `debug_backtrace(` in non-dev code
- Loose `catch (\Exception` blocks that expose error details
- Logging of sensitive data (`password`, `token`, `secret`, `credit_card`)
**Plugin Security**
Per the [Adobe code review best practices](https://experienceleague.adobe.com/en/docs/commerce-operations/implementation-playbook/best-practices/development/code-review):
- Can `around` plugins be avoided? Prefer `before`/`after` when possible
- Do plugins return the correct types of data? Incorrect return types are a security risk
- Is any new type of data exposed to any type of user (admin or frontend)? Is that exposure a security risk?
- Is user-generated data validated? Everything from the browser is user-generated, including cookie values and server headers
### Phase 2: Access Control Review
1. List all controllers (admin and frontend) in the module
2. Verify each admin controller has `ADMIN_RESOURCE`
3. Verify each frontend controller validates customer session where needed
4. Check `webapi.xml` for proper `<resource>` definitions
5. Review `acl.xml` for proper ACL tree structure

### Phase 3: Data Flow Analysis
For each user input entry point:
1. Trace the input from controller → service → persistence
2. Verify input validation at the controller boundary
3. Verify output escaping at the template layer
4. Flag any path where input reaches SQL, shell, or output without sanitization

### Phase 4: Privacy and GDPR Review
Per the [Adobe code review best practices](https://experienceleague.adobe.com/en/docs/commerce-operations/implementation-playbook/best-practices/development/code-review):
1. Identify code that handles customer data or emails — flag for special attention
2. Check for data leaking between loop iterations (imports, cron jobs, transactional emails, batch queue handlers)
3. Verify factories or repositories are used to create models inside loops — models must not be accessible outside the loop cycle
4. Check that no PII is logged or exposed in error messages

## Output Format
```
## Security Audit: {Module/Scope}

### Risk Summary
- Critical: X | High: X | Medium: X | Low: X
- OWASP Categories Affected: {list}

### Findings

#### [CRITICAL] A03-Injection: {Title}
**File**: `path/to/file.php:42`
**Vector**: User input via {source} reaches {sink} without sanitization
**Impact**: {what an attacker could do}
**Remediation**: {specific fix with code example}

### Recommendations
- {Prioritized list of fixes}
```

## References
- [OWASP Top 10 (2021)](https://owasp.org/Top10/)
- [Magento Security Best Practices](https://developer.adobe.com/commerce/php/development/security/)
- [Adobe Commerce Security Guide](https://experienceleague.adobe.com/docs/commerce-operations/security-and-compliance/overview.html)
