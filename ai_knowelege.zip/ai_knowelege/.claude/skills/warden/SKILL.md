---
name: warden
description: "How to actually run Magento/Composer/PHP/shell commands and manage services in this project's Warden environment. Use whenever you need to run bin/magento, composer, phpunit, phpcs, php, or any other command inside the project's containers, or need to check container/service status. Supersedes the shorthand command prefixes in CLAUDE.md, which do not work as written in this Warden install (v0.16.1) — see Gotchas."
metadata:
  category: "environment"
  project: "magento_cosmetics"
  scope: "Local Development (Warden)"
---

# warden

This project (`legal.test`, Warden env name `legal`) runs entirely inside Warden-managed Docker
containers. **Never run `php`, `composer`, or `bin/magento` directly on the host** — they don't
exist there; everything must go through one of the verified invocations below.

## Verified working invocations

| Task | Command |
|---|---|
| Magento CLI | `warden env exec -T php-fpm bin/magento <cmd>` |
| Composer | `warden env exec -T php-fpm composer <cmd>` |
| One-off shell command (php, phpunit, phpcs, git, etc.) | `warden shell -c "<cmd>"` |
| Interactive shell | `warden shell` (no args) |
| DB access | see the `local-database-access` skill (`warden db connect …`) |
| List/check running containers | `warden env ps` |

Examples actually run and confirmed in this project:

```bash
warden env exec -T php-fpm bin/magento setup:upgrade
warden env exec -T php-fpm bin/magento setup:di:compile
warden env exec -T php-fpm bin/magento cache:flush
warden env exec -T php-fpm bin/magento module:status
warden env exec -T php-fpm composer show <package>

warden shell -c "vendor/bin/phpunit --version"
warden shell -c "vendor/bin/phpcs --version"
warden shell -c "php -v"
```

Use `-T` (`--no-tty`) with `warden env exec` when running non-interactively (e.g. from a script or
agent) — without it, `docker compose exec` tries to allocate a TTY and can hang or error in
non-interactive contexts.

The php-fpm service container is `php-fpm` (there is also a `php-debug` service with Xdebug
enabled, same image, use only when you actually need step debugging).

## Gotchas

- **`warden magento <cmd>`, `warden composer <cmd>`, and `warden shell -- <cmd>` — as documented
  in this repo's `CLAUDE.md` — do NOT work** with the installed Warden CLI (v0.16.1). `warden
  magento` / `warden composer` are not real subcommands: they silently fall through to the
  top-level help text and exit non-zero with no useful output. `warden shell -- bin/magento
  --version` does not pass the command through a shell, so it feeds the PHP source of
  `bin/magento` to `sh` line-by-line and fails with nonsense syntax errors. Use the invocations in
  the table above instead — they were tested directly in this environment.
- **`var/` is excluded from the host↔container file sync.** The project root is synced into the
  `legal_appdata` Docker volume (not a plain bind mount — Warden uses a sync mechanism, not
  Docker's native bind mount, for performance on macOS), except `var/log` and `pub/media`, which
  are direct bind mounts, and `var/` itself, which is **not** synced at all: a file written to
  `var/<anything>` from the host never appears in the container, and vice versa. If you need a
  temporary verification script (e.g. a one-off bootstrap script to exercise a class without a
  full HTTP request), write it to the **project root** or under `app/code/...`, run it via `warden
  shell -c "php your_script.php"`, then delete it from both sides — sync in each direction takes
  roughly 1–2 seconds, so a command immediately after a host-side write/delete can race the sync;
  add a short pause or re-check with `warden env exec -T php-fpm ls <path>` if a file seems
  missing/still present.
- Container names are prefixed with the env name, e.g. `legal-php-fpm-1`, `legal-db-1` — useful
  for `docker inspect`/`docker logs` when `warden` subcommands aren't granular enough.
- `warden env ps` must be run from within the project directory (or any subdirectory) — Warden
  resolves the environment from `.warden/warden-env.yml` relative to the cwd.
