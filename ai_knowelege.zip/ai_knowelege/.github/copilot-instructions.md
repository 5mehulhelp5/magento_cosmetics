# Copilot Instructions — magento_cosmetics

## What This Repository Is

This repository (`/Users/mac/projects/magento`) is a **Warden-managed Magento 2.4.9 Community Edition** project. The repository root **is** the Magento application root — `app/`, `composer.json`, `pub/`, `vendor/`, etc. live here directly. There is no nested project subdirectory.

- **GitHub:** `git@github.com:Uho67/magento_cosmetics.git`
- **Warden env name:** `legal` — local domain: `legal.test`
- **Production:** VPS running Docker Compose (`deploy/docker-compose.prod.yml`), deploy path `/srv/legal/`

## Container Execution (CRITICAL)

All PHP/Composer/Magento/PHPUnit/PHPCS/PHPStan/DB commands must go through Warden — **never directly on the host**:

- `warden magento <cmd>` — e.g. `setup:upgrade`, `setup:di:compile`, `cache:flush`, `indexer:reindex`
- `warden composer <cmd>` — e.g. `require`, `update`, `show`, `dump-autoload`
- `warden shell -- <cmd>` — e.g. `php -v`, `vendor/bin/phpstan`, `vendor/bin/phpcs`, `vendor/bin/phpunit`

The container mounts the repo root as `/var/www/html`.

## The AI-Engineering Layers

Full reference docs live in `.github/docs/`: `agents.md`, `skills.md`, `instructions.md`, `prompts.md`, `hooks.md`, `workflow.md`.

- **Instructions** (`.github/instructions/*.instructions.md`) — auto-load based on file glob (`applyTo`). Covers Magento PHP conventions, OWASP security, PHTML/XSS, XML config, JS/frontend, theme development, quality gates, and Jira ticket auto-detection.
- **Agents** (`.github/agents/*.agent.md`) — role-scoped personas invoked via `@agent-name`: `@magento-architect` (plan), `@magento-module-builder` / `@magento-implementation` (build), `@magento-quality` (gate runner), `@security-reviewer` (read-only OWASP review), `@magento-upgrade` (version upgrade planning), `@hyva-helper` (Hyvä theme frontend).
- **Skills** (`.github/skills/*/SKILL.md`) — reusable procedures: `code-review`, `performance-review`, `accessibility`, `phpunit`, `security-audit`, `module-documentation`, `elasticsearch`, `hyva-csp`.
- **Prompts** (`.github/prompts/*.prompt.md`) — one-shot prompts: `pre-commit-check`, `alpine-script`, `review`, `jira-comment`, `jira-context`.
- **Hooks** (`.github/hooks/`) — deterministic pre-write enforcement. `security-gate.json` + `scripts/security-gate.sh` scan PHP edits for dangerous patterns (`PreToolUse` event).

## Typical Workflow

1. **Plan** — `@magento-architect` produces an architecture plan for a new module/feature/integration.
2. **Human review** — developer reviews and approves the plan before implementation starts.
3. **Implement** — `@magento-module-builder` (new modules) or `@magento-implementation` (existing plans) builds the code; `magento-php` + `security-php` instructions auto-load.
4. **Quality gates** — `@magento-quality` runs Code Review → Performance Review → Accessibility → PHPUnit → Security Audit → Module Documentation, auto-fixing and re-running each gate (max 3 iterations).

## Jira Integration

Ticket IDs matching `[A-Z][A-Z0-9]+-\d+` (project prefix: `COS`) mentioned in conversation trigger automatic context lookup via the Jira DC REST API. Credentials are read from `.env` (`JIRA_DC_URL`, `JIRA_ACCESS_TOKEN`) — never print or commit these values.

## Stack

| Layer | Technology |
|---|---|
| PHP | 8.4 (FPM) |
| Database | MariaDB 11.4 |
| Search | OpenSearch 2.19 |
| Cache/Sessions | Valkey 8 (Redis-compatible) |
| Queue | RabbitMQ 3.13 |
| HTTP cache | Varnish |
| Web server | Nginx |
