# Agents Reference

> Specialized personas with restricted tool access. Use for focused, role-isolated tasks.

[← Back to overview](../README.md)

## How Agents Work

Agents are `.agent.md` files in `.github/agents/`. Each defines a persona with specific expertise, constraints, and a restricted set of tools. This means an agent **cannot** do things outside its role — a security reviewer can read code but cannot edit files.

Invoke agents via `@agent-name` in chat or let Copilot delegate to them automatically when it detects a matching task.

## Available Agents

### @security-reviewer

| | |
|---|---|
| **Location** | `.github/agents/security-reviewer.agent.md` |
| **Tools** | `read`, `search` (read-only — cannot modify files) |
| **Purpose** | Security-focused code review for OWASP compliance |

**Expertise:**
- OWASP Top 10 (2021) applied to Magento 2 / PHP 8.x
- Magento-specific: ObjectManager abuse, unescaped templates, ACL bypass, CSRF

**Skills used:**
- `security-audit` — provides the concrete OWASP search patterns for Phase 1 pattern scanning

**Constraints:**
- Read-only — will not modify any files
- Only reports security findings (not style or performance)
- Focuses on custom code directory (`app/`)

**Approach:**
1. Loads the `security-audit` skill for the full Phase 1 pattern scan
2. Reads target files/module
3. Scans for dangerous patterns from OWASP categories
4. Traces user input from entry points (controllers, API, GraphQL) to sinks (DB, shell, output)
5. Checks access control on all controllers and API endpoints
6. Verifies template output escaping
7. Checks that `around` plugins return correct types — incorrect return types can be a security risk
8. Verifies user-generated data is validated — everything from the browser is user-generated, including cookies and server headers
9. Reviews privacy/GDPR concerns (customer data isolation, data leaking between loop iterations)

**Usage:**
```
@security-reviewer Review app/module-mage-api/ for vulnerabilities
@security-reviewer Check if the new checkout controller has proper ACL
```

---

### @magento-architect

| | |
|---|---|
| **Location** | `.github/agents/magento-architect.agent.md` |
| **Tools** | `read`, `search`, `edit`, `execute`, `agent`, `todo`, `web`, `MySQL` |
| **Purpose** | Architecture guidance for Magento 2 module design and integration planning |

**Expertise:**
- Magento 2 module architecture, service contracts, and canonical file structure
- Multi-website / multi-store patterns
- ERP integration patterns (sync, async, queue-based)
- Performance architecture (caching, FPC, public vs private content, indexing)
- Theme architecture (static vs dynamic view files, module-scoped overrides)

**Project context:**
- Derives project structure from actual files (monorepo, multi-store, single-instance, etc.)

**Constraints:**
- Advisory only — provides architecture guidance, not implementation code
- Uses MySQL to _read_ schema and table structures (never modifies data)
- Uses terminal (`execute`) _only_ to fetch Jira ticket context via `.env` + REST API — no other shell use
- Uses web to fetch external documentation when needed
- Delegates security assessments to @security-reviewer via agent tool
- Prefers plugins over rewrites, service contracts over direct coupling

**Usage:**
```
@magento-architect How should I structure a new ERP integration for the Czech market?
@magento-architect What's the dependency impact of adding a new core module?
@magento-architect Should I use a message queue or synchronous call for order sync?
@magento-architect Review the DB schema for a custom module
```

---

### @magento-upgrade

| | |
|---|---|
| **Location** | `.github/agents/magento-upgrade.agent.md` |
| **Tools** | `read`, `search`, `execute`, `edit`, `web`, `todo`, `agent` |
| **Purpose** | Plan Adobe Commerce / Magento 2 version upgrades end-to-end |

**Expertise:**
- Adobe Commerce and Magento 2 release cycles, EOL dates, and system requirements
- Stack compatibility across PHP, MySQL/MariaDB, Elasticsearch/OpenSearch, Redis, RabbitMQ, Varnish
- Adobe Commerce Cloud config files (`.magento.app.yaml`, `.magento/services.yaml`, `.magento.env.yaml`)
- Third-party Composer dependency auditing and risk categorisation
- Custom module PHP compatibility analysis (PHPStan, PHP_CodeSniffer / PHPCompatibility)
- Breaking change patterns between minor and patch versions (deprecated APIs, TinyMCE → HugeRTE, etc.)
- Security patch release notes and CVE details for security-only upgrades (e.g. 2.4.8-p1 → 2.4.8-p2)
- Composer patches applicability (`cweagans/composer-patches`, `m2-hotfixes/`)
- B2B extension compatibility

**Constraints:**
- Read-only by default — never runs `composer update`, `setup:upgrade`, database modifications, or file deletions
- `execute` (terminal) is restricted to read-only analysis: `composer show`, `php -v`, `grep`, `find`, `cat`, static analysis tools, `curl` for Jira context
- Does **not** modify application source code — produces the upgrade **plan**, not the code changes
- Delegates security-focused audits to `@security-reviewer`
- Delegates architectural decisions to `@magento-architect`
- All version numbers and breaking changes must come from verified sources — never guessed

**Approach:**

1. Asks for the target version if not specified
2. Detects deployment type (Cloud vs. on-premise) from project config files
3. Discovers current stack: Adobe Commerce version, PHP, infrastructure services, Composer dependencies, custom modules
4. Fetches target version system requirements and release notes via the `web` tool
5. Audits third-party dependencies for compatibility (HIGH / Medium / Low risk)
6. Scans custom modules for PHP compatibility and breaking-change surface
7. For Cloud projects: audits `.magento.app.yaml`, `.magento/services.yaml`, `.magento.env.yaml` against target requirements
8. Generates a structured upgrade plan at `docs/upgrade/upgrade-plan-{target-version}.md`

**Output:** a versioned Markdown document covering executive summary, complexity assessment, breaking changes, dependency risk matrix, custom module audit, pre-upgrade checklist, execution steps, post-upgrade validation, rollback strategy, timeline, and open questions.

**Usage:**
```
@magento-upgrade Plan the upgrade from 2.4.6 to 2.4.8
@magento-upgrade What PHP version do we need for Adobe Commerce 2.4.8?
@magento-upgrade Audit third-party modules for compatibility with 2.4.7-p4
@magento-upgrade Check if our Cloud config needs updating for the 2.4.8 upgrade
```

### @magento-module-builder

| | |
|---|---|
| **Location** | `.github/agents/magento-module-builder.agent.md` |
| **Tools** | `read`, `search`, `edit`, `execute`, `agent`, `todo`, `web` |
| **Purpose** | Build production-ready Magento 2 modules from requirements (direct or Jira) |

**Expertise:**
- Full-stack Magento 2 module development (PHP, XML, PHTML, JS, LESS)
- Automatically applies best-practice instructions from `instructions/` based on file type
- Jira ticket context fetching when a ticket ID is mentioned

**Skills used (quality gates):**
- `code-review` — Magento coding standards, DI, service contracts
- `performance-review` — N+1 queries, caching, FPC impact
- `accessibility` — WCAG 2.1 AA for frontend output
- `phpunit` — Unit test generation and verification
- `security-audit` — OWASP Top 10 scan
- `module-documentation` — README with install, config, API, extension points

**Workflow:**
1. **Gather Requirements** — Fetch Jira context if applicable, summarize, ask clarifying questions (scope, data, integrations, multi-store, API, ACL, events, cron, CLI, admin UI)
2. **Implementation Plan** — Present structured plan with file list, dependencies, schema changes; ask for approval
3. **Implementation** — Build the module file-by-file, applying all matching instructions; structure covers `Api/`, `Model/`, `Controller/`, `Block/`, `ViewModel/`, `Plugin/`, `Observer/`, `Cron/`, `Console/`, `UI/`, `Setup/Patch/Data/`, `etc/db_schema.xml`, `i18n/`, `view/`, `Test/Unit/`
4. **Quality Gates** — Delegates to `@magento-quality` to run all six gates with auto-fix
5. **Delivery Checklist** — Present a pass/fail checklist for all six gates

**Constraints:**
- Uses `db_schema.xml` (declarative schema) over `InstallSchema`/`UpgradeSchema`
- Uses `db_schema_whitelist.json` alongside `db_schema.xml` for safe column operations
- All quality gates must pass before delivery — never skipped
- All other constraints (DI, plugins, ViewModels, template escaping, ACL) are enforced by the loaded instruction files
- Delegates to `@magento-quality` for all quality gates
- Delegates to `@security-reviewer` for deep security analysis
- Delegates to `@magento-architect` for architectural decisions beyond module scope

**Usage:**
```
@magento-module-builder Build a module for custom product badges based on PROJ-1234
@magento-module-builder Create a module that adds a "delivery date" attribute to orders
@magento-module-builder Build the ERP sync module from the requirements in SHOP-567
```

---

### @magento-quality

| | |
|---|---|
| **Location** | `.github/agents/magento-quality.agent.md` |
| **Tools** | `read`, `search`, `edit`, `execute`, `agent`, `todo` |
| **Purpose** | Run all quality gates against a module or file set — auto-fix issues until all gates pass |

**Skills used (quality gates):**
- `code-review` — Magento coding standards, DI, service contracts
- `performance-review` — N+1 queries, caching, FPC impact
- `accessibility` — WCAG 2.1 AA for frontend output
- `phpunit` — Unit test generation and verification
- `security-audit` — OWASP Top 10 scan
- `module-documentation` — README with install, config, API, extension points

**Workflow:**
1. **Identify Target** — Accept a module path or list of changed files from the calling agent or user
2. **Run Quality Gates** — Execute all six skills in order; auto-fix findings and re-run (max 3 iterations per gate before escalating)
3. **Quality Gates Checklist** — Return a pass/fail checklist to the calling agent or user

**Constraints:**
- Never skips a quality gate — if a skill file is unavailable, reports the gap
- Maximum 3 auto-fix iterations per gate before escalating
- Only fixes issues identified by gates — does not refactor or change unrelated code
- Preserves existing code style and conventions when applying fixes
- Delegates to `@security-reviewer` for deep security analysis

**Usage (standalone):**
```
@magento-quality Run quality gates on modules/module-mage-catalog/
@magento-quality Check all gates for the files I just changed
```

**Usage (delegated by other agents):**
`@magento-module-builder` and `@magento-implementation` automatically delegate to this agent during their quality gates phase.

---

### @magento-implementation

| | |
|---|---|
| **Location** | `.github/agents/magento-implementation.agent.md` |
| **Tools** | `read`, `search`, `edit`, `execute`, `agent`, `todo`, `web` |
| **Purpose** | Implement features, improvements, and fixes from a @magento-architect plan — quality gates, auto-fix, delivery checklist |

**Expertise:**
- Full-stack Magento 2 module development (PHP, XML, PHTML, JS, LESS)
- Automatically applies best-practice instructions from `instructions/` based on file type
- Translates architectural plans into production-ready changes in existing modules
- Surgical modifications — reads existing code first, preserves conventions, maintains backward compatibility

**Key difference from @magento-module-builder:**
`@magento-module-builder` builds new modules from scratch (from requirements or Jira tickets). `@magento-implementation` takes an existing architectural plan (from `@magento-architect`) and implements it — typically as features, improvements, or fixes in **existing** modules. This creates a clean **architect → implement** pipeline where design is reviewed before code is written.

**Workflow:**
0. **Load & Validate Plan** — Accept the @magento-architect output (pasted, file path, or conversation reference); parse for target module(s), change type, affected files, and key components; read the existing code to understand the current state; summarize for user confirmation
1. **Create Task List** — Decompose the plan into ordered tasks categorized as Create / Modify / Remove (dependency-first ordering); present and ask for approval
2. **Implement** — Execute changes one by one; read existing files before modifying; preserve coding style and conventions; apply matching instruction files; note any decisions not covered by the plan
3. **Quality Gates** — Delegates to `@magento-quality` to run all six gates with auto-fix
4. **Delivery Checklist** — Present pass/fail checklist for all six gates plus plan adherence and implementation decisions

**Constraints:**
- Uses `db_schema.xml` (declarative schema) over `InstallSchema`/`UpgradeSchema`
- Uses `db_schema_whitelist.json` alongside `db_schema.xml`
- All quality gates must pass before delivery — never skipped
- Never deviates from the architectural plan without explicit user approval
- All other constraints (DI, plugins, ViewModels, template escaping, ACL) enforced by loaded instruction files
- Delegates to `@magento-quality` for all quality gates
- Delegates to `@security-reviewer` for deep security analysis
- Delegates to `@magento-architect` for plan refinement or decisions beyond plan scope

**Usage:**
```
@magento-implementation Implement the plan from @magento-architect for the ERP sync feature
@magento-implementation Here is the architectural plan for the checkout improvement: [paste plan]
@magento-implementation Implement the plan in docs/architecture/order-export-refactor.md
@magento-implementation Apply the @magento-architect plan to fix the inventory sync issue
```

---

### @hyva-helper

| | |
|---|---|
| **Location** | `.github/agents/hyva-helper.agent.md` |
| **Tools** | `read`, `search`, `edit` (+ VS Code equivalents) |
| **Purpose** | Scaffold and fix Hyvä PHTML templates: Alpine.js, CSP, Tailwind, escaping |

**Commands:**
- `--create-template` — injects `HyvaCsp` boilerplate and an Alpine.js `<script>` scaffold; names the function from the filename in camelCase (`cart-drawer.phtml` → `initCartDrawer`)
- `--add-component <Name>` — appends a new named Alpine component to the existing `<script>` block
- `--csp` — audits and auto-fixes CSP compliance and Alpine anti-patterns; reports with `🔧 FIXED` / `⚠️ MANUAL`

**Key rules enforced:**
- `registerInlineScript()` required at the end of every `<script>` block
- `use Hyva\Theme\ViewModel\HyvaCsp;` in strict alphabetical order (`SlevomatCodingStandard.Namespaces.AlphabeticallySortedUses`)
- Output always via `$escaper->escapeHtml|escapeHtmlAttr|escapeUrl|escapeJs` — never `$block->escapeHtml()`
- No `ObjectManager`, no `cacheable="false"`, no RequireJS/KnockoutJS/LESS
- `x-show` preferred over `x-if`; `x-cloak` on Alpine-hidden elements

**Constraints:**
- Focused on Hyvä/Alpine.js frontend only — does not touch PHP business logic
- Does not use RequireJS, KnockoutJS, or LESS

**Usage:**
```
@hyva-helper --create-template
@hyva-helper --add-component ProductGallery
@hyva-helper --csp
```

---

## Creating a New Agent

1. Create `.github/agents/{name}.agent.md`
2. Add frontmatter:
   ```yaml
   ---
   description: "Use when {specific triggers}"
   tools: [read, search]  # Minimal tool set for the role
   ---
   ```
3. Define: persona, expertise, constraints, approach, output format
4. Keep tools minimal — an agent with `[read, search]` cannot accidentally break code
5. Update this doc
