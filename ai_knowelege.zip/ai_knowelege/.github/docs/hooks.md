# Hooks Reference

> Deterministic enforcement that runs automatically — blocks dangerous patterns before they enter the codebase.

[← Back to overview](../README.md)

## Claude Code Security Gate Hook

> **Note:** This hook uses the [Claude Code hook format](https://docs.anthropic.com/en/docs/claude-code/hooks) (`PreToolUse` event, `permissionDecision` output). It is not a GitHub Copilot feature — it runs inside Claude Code (the Anthropic CLI / VS Code extension).

| | |
|---|---|
| **Config** | `.github/hooks/security-gate.json` |
| **Script** | `.github/hooks/scripts/security-gate.sh` |
| **Event** | `PreToolUse` — runs before every file edit/create |
| **Timeout** | 10 seconds |

### What It Does

```mermaid
flowchart TD
    A[Agent wants to edit a file] --> B{Is it a PHP file?}
    B -->|No| C{Is it in a protected path?}
    B -->|Yes| D[Scan new content for<br/>dangerous patterns]
    C -->|No| E[✅ Allow]
    C -->|Yes| F[⚠️ Ask for confirmation]
    D --> G{Pattern found?}
    G -->|No| E
    G -->|Yes| F
```

**Protected paths** (edits require confirmation):
- `vendor/` — Composer-managed dependencies
- `generated/` — Magento-generated factories, proxies, interceptors
- `pub/static/` — Compiled static assets
- `pub/media/` — User-uploaded media files
- `var/` — Cache, logs, sessions
- `node_modules/` — npm/yarn dependencies
- `.github/hooks/` — Protects the hook config from self-modification

**Dangerous PHP patterns** (edits require confirmation):
- `ObjectManager::getInstance`
- `eval(`
- `shell_exec(`
- `unserialize(`
- `$_GET`, `$_POST`, `$_REQUEST`

The hook does NOT block outright — it forces a **human confirmation** before applying code with dangerous patterns. This prevents the AI from silently introducing vulnerable code while preserving the ability to write such code when genuinely needed.

## Customizing

### Adding a Pattern to the Copilot Hook

Edit `.github/hooks/scripts/security-gate.sh` and add to the `DANGEROUS_PATTERNS` array:

```bash
DANGEROUS_PATTERNS=(
    "ObjectManager::getInstance"
    "eval("
    "your_new_pattern"   # ← add here
)
```


