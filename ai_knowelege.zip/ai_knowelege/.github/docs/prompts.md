# Prompts Reference

> Quick one-shot task templates triggered via `/` commands in chat.

[← Back to overview](../README.md)

## How Prompts Work

Prompts are `.prompt.md` files in `.github/prompts/`. Like skills, they appear as slash commands (type `/` in chat). The difference: prompts are **single focused tasks**, while skills are multi-step workflows with bundled assets.

## Available Prompts

### `/jira-context`

| | |
|---|---|
| **Location** | `.github/prompts/jira-context.prompt.md` |
| **Purpose** | Explicitly fetch one or more Jira ticket details and return a structured context summary |

Use when you want to manually load Jira ticket context before starting a task. Accepts comma- or space-separated ticket IDs.

**Steps performed:**
1. Reads `JIRA_DC_URL` and `JIRA_ACCESS_TOKEN` from `.env`
2. Calls `POST /rest/api/2/search` with all provided ticket IDs in a single request
3. Returns per-ticket: summary, status, priority, condensed description, acceptance criteria, linked issues, affected modules

**Output format:**
```
### PROJ-1234: {Summary}
- Status: In Progress | Priority: High
- Description: ...
- Acceptance Criteria: ...
- Affected areas: module-weg-b2b-checkout, CZ/SK environments
```

**When to use:** Explicit lookup before implementing a feature or reviewing a PR. For automatic detection when ticket IDs appear in conversation, the `jira-context.instructions.md` instruction handles this without a manual prompt.

---

### `/review`

| | |
|---|---|
| **Location** | `.github/prompts/review.prompt.md` |
| **Purpose** | Quick code review of a file or module |

Checks code quality in priority order:
1. **Security** — OWASP Top 10: injection, XSS, access control, CSRF; cookies and headers are user-generated
2. **Correctness** — logic errors, edge cases, exception handling
3. **Convention & Structure** — single responsibility, Magento directory conventions, naming, no debug code
4. **Completeness** — config flags, ACL definitions, config scope matches `system.xml`
5. **Magento standards** — DI patterns, plugin usage, repository pattern, ViewModel over Block
6. **Performance** — N+1 queries, collection loads, caching, `cacheable="false"` misuse
7. **Privacy/GDPR** — customer data isolation in loops, factories/repositories in batch cycles
8. **Accessibility (WCAG 2.1 AA)** — frontend code only: alt text, labels, keyboard access, ARIA, contrast
9. **Code style** — PSR-12, strict types, return types

**Output**: Severity per finding + overall pass/needs work/fail.

**When to use**: Quick check on a single file or small change. For a full module audit, use `/code-review` (skill) instead.

---

### `/jira-comment`

| | |
|---|---|
| **Location** | `.github/prompts/jira-comment.prompt.md` |
| **Purpose** | Post a comment to a Jira ticket — either a literal message or an auto-generated summary of current code changes |

**Usage:**
```
/jira-comment INTUSAOPS-127 Fixed the redirect issue by updating the URL builder
/jira-comment INTUSAOPS-127 summary
```

**Steps performed:**
1. Reads `JIRA_DC_URL` and `JIRA_ACCESS_TOKEN` from `.env`
2. Parses ticket ID (`[A-Z][A-Z0-9]+-\d+`) and comment body from the message
3. If body is `summary` or empty — diffs `HEAD`, composes a professional comment from changed files and diff output
4. `POST /rest/api/2/issue/{ticket}/comment` with the comment body
5. Returns ticket link + preview of the posted comment

**When to use:** After finishing a task, to leave a concise progress note or solution summary on the Jira ticket without switching to the browser.

---

### `/pre-commit-check`

| | |
|---|---|
| **Location** | `.github/prompts/pre-commit-check.prompt.md` |
| **Purpose** | Quality gate for staged/changed files before committing |

Runs checks on `git diff` output:

| File Type | Checks |
|-----------|--------|
| **PHP** | `php -l` syntax, `strict_types`, forbidden patterns (ObjectManager, eval, superglobals, etc.), debug code (`var_dump`, `print_r`), Magento patterns (DI, plugins), privacy (customer data in loops), PSR-12, return types |
| **PHTML** | Unescaped output (`echo $` without `$escaper->`) |
| **XML** | Schema URN references, valid structure, `cacheable="false"` not on catalog/product/CMS pages |
| **JS** | `'use strict'`, no `innerHTML`/`.html()` with variables, RequireJS `define()` |

**Output**: Clear PASS/FAIL with all issues listed.

**When to use**: Before committing, as a manual sanity check. For automated enforcement on every commit, install the git pre-commit hook instead (see [Hooks](hooks.md)).

### `/alpine-script`

| | |
|---|---|
| **Location** | `.github/prompts/alpine-script.prompt.md` |
| **Purpose** | Add Alpine.js CSP-safe script boilerplate to a Hyvä PHTML template |

Applies to the active `.phtml` file. Each step is skipped if already present:

1. Inserts `use Hyva\Theme\ViewModel\HyvaCsp;` in alphabetical order among `use` statements
2. Adds `/** @var HyvaCsp $hyvaCsp */` after the last `@var` line
3. Appends a CSP-safe `<script>` block at end of file — function name derived from filename in camelCase (`cart-page.phtml` → `initCartPage`)

Uses targeted string replacements — does not rewrite unchanged code. `registerInlineScript()` is always the last line.

**When to use:** Starting a new Alpine.js component in an existing Hyvä template that has no `<script>` block yet. For fixing CSP issues in an existing script, use `/hyva-csp` (skill) instead.

---

## Creating a New Prompt

1. Create `.github/prompts/{name}.prompt.md`
2. Add frontmatter:
   ```yaml
   ---
   description: "What this prompt does"
   agent: "agent"
   ---
   ```
3. Write a focused, single-task instruction
4. Update this doc
