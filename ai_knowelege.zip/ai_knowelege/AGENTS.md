# Project Rules for AI Coding Agents — magento_cosmetics

## What This Repository Is

This is a **Warden-managed Magento 2.4.9 Community Edition** e-commerce project (`magento/project-community-edition`). The repository root (`/Users/mac/projects/magento`) **is** the Magento application root — `app/`, `composer.json`, `pub/`, `vendor/`, etc. live here directly.

- **GitHub:** `git@github.com:Uho67/magento_cosmetics.git`
- **Warden env name:** `legal` — local domain: `legal.test`
- **Production:** VPS running Docker Compose (`deploy/docker-compose.prod.yml`), deploy path `/srv/legal/`

## Stack

| Layer | Technology |
|---|---|
| PHP | 8.4 (FPM) |
| Database | MariaDB 11.4 |
| Search | OpenSearch 2.19 |
| Cache/Sessions | Valkey 8 (Redis-compatible) |
| Queue | RabbitMQ 3.13 |
| HTTP cache | Varnish |
| Web server | Nginx |

## Container Execution (CRITICAL)

The project runs inside [Warden](https://warden.dev/) locally. **Never run Magento, Composer, or PHP commands directly on the host.** All commands must go through Warden:

| Command prefix | When to use |
|---|---|
| `warden magento <cmd>` | `setup:upgrade`, `setup:di:compile`, `static-content:deploy -f`, `indexer:reindex`, `cache:flush` |
| `warden composer <cmd>` | `require`, `update`, `show`, `dump-autoload` |
| `warden shell -- <cmd>` | anything else: `php -v`, `vendor/bin/phpstan`, `vendor/bin/phpcs`, `vendor/bin/phpunit` |

The container mounts the repo root as `/var/www/html` — paths inside Warden match the host paths relative to the project root.

## Custom Modules

`app/code/` is currently empty. All functionality comes from Magento core and Composer dependencies. New modules should be placed under `app/code/<Vendor>/<Module>/`.

## Documentation

- **Local setup:** `docs/LOCAL_SETUP.md`
- **Production deploy / rollback:** `docs/DEPLOY.md`
- **AI agent toolkit:** `.github/copilot-instructions.md`

## Third-party Dev Tools

- `markshust/magento2-module-disabletwofactorauth` — disables 2FA locally only; 2FA is re-enabled in production
- `mageplaza/magento-2-ukrainian-language-pack` — Ukrainian language support
