# Project Rules for AI Coding Agents — magento_cosmetics

## What This Repository Is

This is a **Warden-managed Magento 2.4.9 Community Edition** e-commerce project (`magento/project-community-edition`). The repository root (`/Users/mac/projects/magento`) **is** the Magento application root — `app/`, `composer.json`, `pub/`, `vendor/`, etc. live here directly.

- **GitHub:** `git@github.com:Uho67/magento_cosmetics.git`
- **Warden env name:** `legal` — local domain: `legal.test`
- **Production:** VPS running Docker Compose (`deploy/docker-compose.prod.yml`), deploy path `/srv/legal/`

## Stack

| Layer | Technology |
|---|---|
| PHP | 8.4 (FPM) |
| Database | MariaDB 11.4 |
| Search | OpenSearch 2.19 |
| Cache/Sessions | Valkey 8 (Redis-compatible) |
| Queue | RabbitMQ 3.13 |
| HTTP cache | Varnish |
| Web server | Nginx |

## Container Execution (CRITICAL)

The project runs inside [Warden](https://warden.dev/) locally. **Never run Magento, Composer, or PHP commands directly on the host.** All commands must go through Warden — see the `warden` skill for the verified working invocations and gotchas (the shorthand `warden magento`/`warden composer`/`warden shell -- <cmd>` prefixes do not work with the installed Warden CLI):

| Command prefix | When to use |
|---|---|
| `warden env exec -T php-fpm bin/magento <cmd>` | `setup:upgrade`, `setup:di:compile`, `static-content:deploy -f`, `indexer:reindex`, `cache:flush` |
| `warden env exec -T php-fpm composer <cmd>` | `require`, `update`, `show`, `dump-autoload` |
| `warden shell -c "<cmd>"` | anything else: `php -v`, `vendor/bin/phpstan`, `vendor/bin/phpcs`, `vendor/bin/phpunit` |

The repo root is synced into the container's `/var/www/html` (via Warden's file sync, not a plain bind mount) — paths match the host paths relative to the project root, but `var/` itself is excluded from that sync in both directions (see the `warden` skill).

## Custom Modules

Custom modules live under `app/code/<Vendor>/<Module>/`. The vendor namespace in use is `Uho`.

## Documentation

- **Local setup:** `docs/LOCAL_SETUP.md`
- **Production deploy / rollback:** `docs/DEPLOY.md`
- **AI agent toolkit:** `.github/copilot-instructions.md`

## Third-party Dev Tools

- `markshust/magento2-module-disabletwofactorauth` — disables 2FA locally only; 2FA is re-enabled in production
- `mageplaza/magento-2-ukrainian-language-pack` — Ukrainian language support
